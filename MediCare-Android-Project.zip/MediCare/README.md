# MediCare 2.0: Medicine Reminder & Monitoring System

Native Android app (Kotlin + Jetpack Compose + Room). 100% offline, no account, no internet permission.
MediCare only reminds you. It never recommends doses or schedules; it stores exactly what you enter.

## What's new in 2.0
- **Redesign:** soft blue/mint gradients, rounded cards, floating pill navigation, animated progress rings, week calendar
  on Home (tap a day to see it), upcoming reminders, personalised greeting (set your name in Settings).
- **Any exact minute:** the time picker lets you TYPE hour and minute (2:12, 8:43, 11:59 PM, 12:01 AM) or step ±1 minute,
  with AM/PM or 24-hour mode and live validation. The date picker is a full calendar (months/years) with keyboard entry.
- **Alarm engine rewrite:** uses `AlarmManager.setAlarmClock` (exact, Doze-proof, no special permission), rings immediately
  from the receiver under a wake lock (previously it waited on the database first, which could be missed while the phone
  slept), double-checks the dose inside the service, and still prevents duplicates.
- **Notifications:** new high-importance channel, tapping a notification opens that exact medicine with Taken / Snooze / Skip,
  lock-screen privacy option, backup channel if Android blocks the alarm service.
- **Settings > Alarm & notification check:** live diagnostics (notifications, channel, battery, full-screen, alarm volume,
  Do Not Disturb, battery saver, registered alarms) with fix buttons, plus test notification and 10-second / 1-minute test alarms.
- **Stable signing key** so future updates install OVER the app without losing data.

## IMPORTANT: updating from the first version
Version 1 was signed with a random GitHub key, so Android will refuse to update it. Do this ONCE:
1. Write down your medicines (the database cannot be moved between differently-signed apps).
2. Uninstall the old MediCare.
3. Install the new APK and re-enter your medicines.
From now on every build uses the fixed key in `app/medicare-debug.keystore`, so later updates keep all data.
(That key is public in this repo: fine for personal use, but a Play Store release needs your own private key.)

## Build the APK
**GitHub (no computer needed):** upload this zip to your repo with the same file name, commit, open **Actions**,
download the `MediCare-APK` artifact when the run is green.
**Android Studio:** File > Open the `MediCare` folder, then Build > Build APK(s) (`app-debug.apk`).
Minimum Android 8.0 (API 26). Targets Android 14.

## First-launch setup (needed on most phones, especially Nubia/Xiaomi/Oppo/Vivo/Huawei/Samsung)
Open **Settings** in the app and use the Setup guide + checks. In short: allow notifications; battery = Unrestricted;
enable Autostart / background activity; lock the app in Recents; never "Force stop" or "Clean all".
Android and phone makers can still stop apps in the background. MediCare uses the most reliable alarm type Android
provides but cannot override your phone's own battery rules, so the checks and tests are there to verify YOUR phone.

## How the alarm system works
- One `setAlarmClock` alarm per (medicine, time of day). Request code = medicineId*2000 + minuteOfDay with
  `FLAG_UPDATE_CURRENT`: rescheduling replaces, never duplicates. Snooze has its own slot per dose.
- On fire: `AlarmReceiver` takes a wake lock, immediately starts `AlarmService` (foreground, media-playback type: looping
  alarm sound, vibration, notification with Mark as Taken / Snooze), then schedules tomorrow's alarm in the background.
- `AlarmService` skips ringing if the dose is already Taken/Skipped or the medicine was deleted.
- Edit or delete: old alarms are cancelled and re-registered. Reboot / app update / clock or timezone change:
  `BootReceiver` re-registers everything. The app also re-registers whenever it is opened (idempotent).
- Nothing is auto-marked Taken. Dismissing a notification records nothing; an unconfirmed dose becomes Missed after 60 minutes.

## QA checklist (run on a real phone; I could not run any of this)
| # | Test | Expected |
|---|------|----------|
| 1 | Set a time of 2:12 PM, then 8:43 AM, 11:59 PM, 12:01 AM | Each is accepted and shown exactly in My Medicines |
| 2 | Pick dates by calendar and by keyboard entry; edit a schedule | Dates saved and shown correctly |
| 3 | Add a medicine 2 minutes ahead at a non-round minute | Rings at that exact minute |
| 4 | Airplane mode, repeat 3 | Still rings |
| 5 | App in background / screen off | Rings |
| 6 | Remove app from Recents, wait | Rings (needs battery/autostart setup) |
| 7 | Restart phone, do not open app | Next alarm rings |
| 8 | Tap Snooze, then Mark as Taken (notification and in-app) | Re-rings after snooze; Taken appears in Home and Monitoring |
| 9 | Tap the notification body | Opens a dialog for that medicine |
| 10 | Edit a medicine several times | Rings once, no duplicates |
| 11 | Settings > check list and all tests | All green / tests ring |

## Cannot be verified without a physical Android device
Real alarm timing, sound and vibration, behaviour after restart or swipe-away on your specific phone brand,
lock-screen and full-screen behaviour, and the look on different screen sizes. The project also has not been compiled here,
so Android Studio / GitHub may report a small build error on the first run; send it over and it gets fixed.

## Project layout
`Data.kt` Room + repository, `Alarms.kt` scheduler / notifications / receivers / service, `Prefs.kt` settings,
`Theme.kt` theme, `Ui.kt` all screens and pickers, `MainActivity.kt` app, ViewModel, notification deep link.
