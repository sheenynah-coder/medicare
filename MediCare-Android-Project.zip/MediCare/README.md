# MediCare: Medicine Reminder & Monitoring System

Native Android app (Kotlin + Jetpack Compose + Room). 100% offline, no account, no internet permission.
MediCare only reminds you. It never recommends doses or schedules; it stores exactly what you enter.

## Build the APK (Android Studio)
1. Install **Android Studio Koala (2024.1) or newer** (it bundles JDK 17 and the Android SDK).
2. **File > Open** and select this `MediCare` folder. Wait for "Gradle sync" to finish
   (first sync downloads Gradle 8.7 and libraries, so it needs internet once).
   If asked to install Android SDK 34, accept.
3. **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Click **locate** in the popup. The file is `app/build/outputs/apk/debug/app-debug.apk`.

Command line alternative (after Studio has generated `gradlew`, or with Gradle 8.7 installed):
`gradle assembleDebug`

## Install on your phone
- **USB:** enable Developer options + USB debugging, plug in, press the green Run button in Android Studio.
- **APK file:** copy `app-debug.apk` to the phone, open it, and allow "Install unknown apps" when asked.
- Minimum Android 8.0 (API 26). Targets Android 14.

## First launch checklist (important for alarms)
1. Allow **Notifications** when asked.
2. Settings > Permissions: if it says exact alarms are off, tap **Allow exact alarms**.
   (If you refuse, MediCare falls back to `setAlarmClock`, which is still exact but shows an alarm icon.)
3. Settings > **Open battery settings**, set MediCare to *Unrestricted / Don't optimize*.
   Xiaomi/Redmi/POCO, Oppo/Realme, Vivo, Huawei, Samsung: also enable **Autostart** / **Allow background activity**
   and lock the app in the Recents screen. Without this some phones kill alarms.
4. Settings > **Test alarm (10 seconds)**, then close the app and lock the phone.

## How the alarm system works
- `AlarmScheduler` registers one `AlarmManager.setExactAndAllowWhileIdle` alarm per (medicine, time of day).
  Request code = medicineId*2000 + minuteOfDay with `FLAG_UPDATE_CURRENT`, so rescheduling replaces, never duplicates.
- When it fires, `AlarmReceiver` schedules the next day's alarm, then starts `AlarmService` (foreground service):
  looping alarm sound (USAGE_ALARM), vibration, full-screen notification with **Mark as Taken** and **Snooze**.
- Snooze uses its own alarm slot per dose, so it also can't duplicate. Sound auto-stops after 2 minutes.
- `BootReceiver` re-registers all alarms after reboot, app update, time change, timezone change, and when the
  exact-alarm permission changes. The app also re-registers on every open (idempotent).
- If Android blocks the foreground service, a backup high-priority notification channel with alarm sound is used.
- **Nothing is ever auto-marked Taken.** Dismissing a notification records nothing. A dose with no confirmation
  becomes **Missed** 60 minutes after its time (checked on app open, on each alarm, and after boot).
  You can still mark a Missed dose as Taken from Home if you took it late.

## Adherence formula
Taken ÷ (Taken + Missed + Skipped) for the selected day (Daily) or the 7 days ending on it (Weekly).

## Manual test checklist (run on a real device)
| # | Scenario | How | Expected |
|---|----------|-----|----------|
| 1 | Add and save | Add Medicine, fill form, Save | Appears in My Medicines and Home; survives app restart |
| 2 | Edit / delete | My Medicines > Edit / Delete | Changes saved; deleted one stops ringing |
| 3 | Alarm at scheduled time | Add a dose 2 minutes ahead | Sound, vibration, notification with name, dosage, time |
| 4 | Offline | Turn on Airplane mode, repeat 3 | Still rings (app has no internet permission) |
| 5 | App closed | Swipe app away, lock phone, wait | Alarm still rings |
| 6 | Mark Taken | Tap Mark as Taken on the notification | Sound stops; Home shows Taken |
| 7 | Monitoring updates | Open Monitoring | Counts, adherence %, calendar dot updated |
| 8 | Reboot | Restart phone, don't open the app | Next dose still rings |
| 9 | No duplicates | Edit a medicine 3 times, wait for the time | Rings once; snooze rings once |
| 10 | Dismiss safety | Swipe the timed-out notification | Dose is NOT marked Taken (becomes Missed after 60 min) |

## Project layout
- `Data.kt` Room entities, DAO, database, repository, missed-dose logic
- `Alarms.kt` scheduler, notifications, receivers, alarm service, boot receiver
- `Prefs.kt` local settings, `Theme.kt` light/dark theme, `Ui.kt` all five screens, `MainActivity.kt` app + ViewModel

## Known limits
- This project was written without being compiled or run on a device. Android Studio will tell you on first sync
  if any version needs a bump. Alarm behavior varies by phone brand, so test on your own device.
- The debug APK is signed with a debug key (fine for personal use). For a Play Store release you need your own keystore.
