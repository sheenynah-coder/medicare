package com.medicare.app

import android.app.NotificationManager
import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate
import java.time.ZoneId

/** A medicine the user entered. MediCare never suggests doses; it stores exactly what the user typed. */
@Entity(tableName = "medicines")
data class Medicine(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val dosage: String,
    val frequency: String,
    val times: String,          // comma separated minutes since midnight, e.g. "480,1200"
    val startDay: Long,         // LocalDate epoch day
    val endDay: Long,           // epoch day, or -1 = no end date
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    fun minuteList(): List<Int> = times.split(",").mapNotNull { it.toIntOrNull() }.distinct().sorted()
    fun isActive(day: Long): Boolean = day >= startDay && (endDay < 0 || day <= endDay)
}

/** One confirmed outcome for one scheduled dose. Status: TAKEN, MISSED or SKIPPED. */
@Entity(
    tableName = "dose_logs",
    indices = [Index(value = ["medicineId", "day", "minutes"], unique = true)]
)
data class DoseLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val medicineId: Long,
    val medicineName: String,
    val dosage: String,
    val day: Long,
    val minutes: Int,
    val status: String,
    val loggedAt: Long
)

data class DoseItem(val m: Medicine, val day: Long, val min: Int, val status: String)

@Dao
interface MedDao {
    @Query("SELECT * FROM medicines ORDER BY name COLLATE NOCASE") fun medicines(): Flow<List<Medicine>>
    @Query("SELECT * FROM medicines") suspend fun allMedicines(): List<Medicine>
    @Query("SELECT * FROM medicines WHERE id = :id") suspend fun medicine(id: Long): Medicine?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(m: Medicine): Long
    @Delete suspend fun delete(m: Medicine)

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertLog(l: DoseLog)
    @Query("SELECT * FROM dose_logs WHERE medicineId = :id AND day = :day AND minutes = :min")
    suspend fun log(id: Long, day: Long, min: Int): DoseLog?
    @Query("SELECT * FROM dose_logs ORDER BY day, minutes") fun allLogs(): Flow<List<DoseLog>>
}

@Database(entities = [Medicine::class, DoseLog::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): MedDao

    companion object {
        @Volatile private var instance: AppDb? = null
        fun get(ctx: Context): AppDb = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "medicare.db")
                .build().also { instance = it }
        }
    }
}

object Repo {
    /** A dose with no confirmation becomes "Missed" this long after its scheduled time. */
    const val GRACE = 60 * 60 * 1000L

    fun dueMillis(day: Long, min: Int): Long =
        LocalDate.ofEpochDay(day).atStartOfDay(ZoneId.systemDefault()).plusMinutes(min.toLong())
            .toInstant().toEpochMilli()

    /** Records unconfirmed doses older than GRACE as MISSED (looks back up to 30 days). */
    suspend fun markOverdue(ctx: Context) {
        val dao = AppDb.get(ctx).dao()
        val now = System.currentTimeMillis()
        val today = LocalDate.now().toEpochDay()
        for (m in dao.allMedicines()) {
            for (day in maxOf(m.startDay, today - 30)..today) {
                if (!m.isActive(day)) continue
                for (min in m.minuteList()) {
                    val due = dueMillis(day, min)
                    if (due < m.createdAt || now < due + GRACE) continue
                    if (dao.log(m.id, day, min) == null) {
                        dao.upsertLog(DoseLog(medicineId = m.id, medicineName = m.name, dosage = m.dosage,
                            day = day, minutes = min, status = "MISSED", loggedAt = now))
                    }
                }
            }
        }
    }

    /** Only called from an explicit user action (button tap). Dismissing a notification never calls this. */
    suspend fun record(ctx: Context, medId: Long, day: Long, min: Int, status: String) {
        val dao = AppDb.get(ctx).dao()
        val m = dao.medicine(medId) ?: return
        dao.upsertLog(DoseLog(medicineId = m.id, medicineName = m.name, dosage = m.dosage,
            day = day, minutes = min, status = status, loggedAt = System.currentTimeMillis()))
        ctx.getSystemService(NotificationManager::class.java).cancel(AlarmScheduler.code(medId, min))
        AlarmScheduler.cancelSnooze(ctx, medId, min)
        ctx.stopService(android.content.Intent(ctx, AlarmService::class.java))
    }

    suspend fun save(ctx: Context, m: Medicine) {
        val dao = AppDb.get(ctx).dao()
        markOverdue(ctx)
        if (m.id != 0L) dao.medicine(m.id)?.let { AlarmScheduler.cancelAll(ctx, it) }
        dao.upsert(m)
        AlarmScheduler.rescheduleAll(ctx)
    }

    suspend fun delete(ctx: Context, m: Medicine) {
        AlarmScheduler.cancelAll(ctx, m)
        AppDb.get(ctx).dao().delete(m)
    }

    fun buildDoses(meds: List<Medicine>, logs: List<DoseLog>, day: Long, now: Long): List<DoseItem> =
        meds.filter { it.isActive(day) }.flatMap { m ->
            m.minuteList().mapNotNull { min ->
                val log = logs.firstOrNull { it.medicineId == m.id && it.day == day && it.minutes == min }
                val due = dueMillis(day, min)
                when {
                    log != null -> DoseItem(m, day, min, log.status)
                    due < m.createdAt -> null
                    now < due -> DoseItem(m, day, min, "UPCOMING")
                    now < due + GRACE -> DoseItem(m, day, min, "DUE")
                    else -> DoseItem(m, day, min, "MISSED")
                }
            }
        }.sortedBy { it.min }
}

fun fmtTime(min: Int, h24: Boolean): String {
    val h = min / 60
    val m = min % 60
    return if (h24) "%02d:%02d".format(h, m)
    else "%d:%02d %s".format(if (h % 12 == 0) 12 else h % 12, m, if (h < 12) "AM" else "PM")
}
