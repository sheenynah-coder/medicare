package com.medicare.app

import android.Manifest
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime
import java.time.YearMonth
import java.time.format.DateTimeFormatter

// ---------- palette & small helpers ----------

private val Green = Color(0xFF2E9E5B)
private val Red = Color(0xFFD64545)
private val Grey = Color(0xFF7A8A96)
private val Orange = Color(0xFFE08A00)
private val Blue = Color(0xFF3D8BE0)
private val HeaderBrush = Brush.linearGradient(listOf(Color(0xFF5AA9F0), Color(0xFF6CCFA6)))
private val HPad = Modifier.padding(horizontal = 16.dp)

private fun statusInfo(s: String): Pair<String, Color> = when (s) {
    "TAKEN" -> "Taken" to Green
    "MISSED" -> "Missed" to Red
    "SKIPPED" -> "Skipped" to Grey
    "DUE" -> "Due now" to Orange
    else -> "Upcoming" to Blue
}

private fun dayText(epoch: Long, pattern: String = "EEE, MMM d") =
    LocalDate.ofEpochDay(epoch).format(DateTimeFormatter.ofPattern(pattern))

@Composable
fun rememberResumeTick(): Int {
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    return tick
}

@Composable
fun StatusChip(status: String) {
    val (text, color) = statusInfo(status)
    Surface(color = color.copy(alpha = 0.15f), shape = RoundedCornerShape(50)) {
        Text(text, color = color, fontWeight = FontWeight.Bold, fontSize = 15.sp,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp))
    }
}

@Composable
fun BigButton(text: String, modifier: Modifier = Modifier, color: Color? = null, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.heightIn(min = 58.dp),
        shape = RoundedCornerShape(50),
        colors = if (color != null) ButtonDefaults.buttonColors(containerColor = color) else ButtonDefaults.buttonColors()
    ) { Text(text) }
}

@Composable
private fun GradientHeader(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 36.dp, bottomEnd = 36.dp))
            .background(HeaderBrush)
            .padding(horizontal = 22.dp, vertical = 22.dp),
        content = content
    )
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            content()
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        Switch(checked, onChange)
    }
}

@Composable
private fun Modifier.horizontalScrollCompat(): Modifier = this.then(Modifier.horizontalScroll(rememberScrollState()))

/** Animated circular progress ring. */
@Composable
fun ProgressRing(
    progress: Float, ringSize: Dp, label: String, sub: String,
    arc: Color = Color.White, track: Color = Color.White.copy(alpha = 0.3f), textColor: Color = Color.White
) {
    val anim by animateFloatAsState(progress.coerceIn(0f, 1f), tween(900), label = "ring")
    Box(Modifier.size(ringSize), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 14.dp.toPx()
            val inset = stroke / 2
            val arcSize = Size(this.size.width - stroke, this.size.height - stroke)
            drawArc(track, 0f, 360f, false, Offset(inset, inset), arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            if (anim > 0f) drawArc(arc, -90f, 360f * anim, false, Offset(inset, inset), arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, color = textColor, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            Text(sub, color = textColor.copy(alpha = 0.9f), fontSize = 14.sp)
        }
    }
}

@Composable
fun DoseCard(d: DoseItem, h24: Boolean, canAct: Boolean, onTaken: () -> Unit, onSkip: () -> Unit) {
    val (_, color) = statusInfo(d.status)
    Card(
        Modifier.fillMaxWidth().animateContentSize(), shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(62.dp).clip(RoundedCornerShape(20.dp)).background(color.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center) {
                    Text(d.m.name.take(1).uppercase(), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = color)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(d.m.name, style = MaterialTheme.typography.titleMedium)
                    Text(d.m.dosage, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(fmtTime(d.min, h24), style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary)
                }
                StatusChip(d.status)
            }
            if (d.m.notes.isNotBlank()) Text(d.m.notes, style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (canAct && (d.status == "UPCOMING" || d.status == "DUE" || d.status == "MISSED")) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onTaken, Modifier.weight(1f).heightIn(min = 54.dp), shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("✓ Taken") }
                    FilledTonalButton(onSkip, Modifier.weight(1f).heightIn(min = 54.dp), shape = RoundedCornerShape(50)) { Text("Skip") }
                }
            }
        }
    }
}

// ---------- root, splash, navigation ----------

@Composable
fun MediCareRoot(vm: MainVM) {
    val dark = when (vm.prefs.theme) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    MediCareTheme(dark) {
        var splash by remember { mutableStateOf(true) }
        LaunchedEffect(Unit) { delay(1300); splash = false }
        Crossfade(targetState = splash, animationSpec = tween(500), label = "splash") { s ->
            if (s) Splash() else MainScaffold(vm)
        }
    }
}

@Composable
fun Splash() {
    Column(
        Modifier.fillMaxSize().background(HeaderBrush),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(painterResource(R.drawable.ic_launcher_foreground), null, Modifier.size(180.dp))
        Text("MediCare", color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.ExtraBold)
        Text("Medicine Reminder & Monitoring System", color = Color.White.copy(alpha = 0.92f),
            fontSize = 17.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 32.dp, vertical = 8.dp))
    }
}

@Composable
private fun NavItem(label: String, icon: ImageVector, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent, label = "navbg")
    val tint by animateColorAsState(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant, label = "navtint")
    Column(
        modifier.clip(RoundedCornerShape(22.dp)).background(bg).clickable(onClick = onClick).padding(vertical = 8.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, tint = tint, modifier = Modifier.size(26.dp))
        Text(label, fontSize = 10.5.sp, maxLines = 2, textAlign = TextAlign.Center, lineHeight = 12.sp, color = tint,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
fun MainScaffold(vm: MainVM) {
    val ctx = LocalContext.current
    val meds by vm.medicines.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<Medicine?>(null) }
    var formKey by remember { mutableIntStateOf(0) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    val navItems = listOf("Home" to Icons.Filled.Home, "Add Medicine" to Icons.Filled.Add,
        "My Medicines" to Icons.Filled.Menu, "Monitoring" to Icons.Filled.DateRange, "Settings" to Icons.Filled.Settings)

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            Surface(
                Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                shape = RoundedCornerShape(32.dp), shadowElevation = 10.dp, color = MaterialTheme.colorScheme.surface
            ) {
                Row(Modifier.padding(6.dp)) {
                    navItems.forEachIndexed { i, (label, icon) ->
                        NavItem(label, icon, tab == i, Modifier.weight(1f)) {
                            if (i == 1 && tab != 1) { editing = null; formKey++ }
                            tab = i
                        }
                    }
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            Crossfade(targetState = tab, animationSpec = tween(250), label = "tabs") { t ->
                when (t) {
                    0 -> HomeScreen(vm, onAdd = { editing = null; formKey++; tab = 1 }, onSettings = { tab = 4 })
                    1 -> key(formKey) { AddEditScreen(vm, editing) { editing = null; formKey++; tab = 2 } }
                    2 -> MyMedicinesScreen(vm, onEdit = { editing = it; formKey++; tab = 1 }, onAdd = { editing = null; formKey++; tab = 1 })
                    3 -> MonitoringScreen(vm)
                    else -> SettingsScreen(vm)
                }
            }
        }
    }

    // Opened from a notification: show that exact medicine and its actions.
    vm.openDose?.let { ref ->
        val med = meds.firstOrNull { it.id == ref.medId }
        if (med != null) {
            AlertDialog(
                onDismissRequest = { vm.openDose = null },
                shape = RoundedCornerShape(28.dp),
                title = { Text("Time to take ${med.name}") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Dosage: ${med.dosage}", style = MaterialTheme.typography.bodyLarge)
                        Text("Scheduled: ${fmtTime(ref.min, vm.prefs.use24h)}", style = MaterialTheme.typography.bodyLarge)
                        if (med.notes.isNotBlank()) Text(med.notes, style = MaterialTheme.typography.bodyMedium)
                    }
                },
                confirmButton = { TextButton({ vm.recordRef(ref, "TAKEN"); vm.openDose = null }) { Text("Mark as Taken", fontSize = 18.sp) } },
                dismissButton = {
                    Row {
                        TextButton({ vm.snooze(ref); vm.openDose = null }) { Text("Snooze ${vm.prefs.snoozeMin} min", fontSize = 16.sp) }
                        TextButton({ vm.recordRef(ref, "SKIPPED"); vm.openDose = null }) { Text("Skip", fontSize = 16.sp) }
                    }
                }
            )
        } else {
            LaunchedEffect(ref) { vm.openDose = null }
        }
    }
}

// ---------- 1. Home ----------

@Composable
fun HomeScreen(vm: MainVM, onAdd: () -> Unit, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val meds by vm.medicines.collectAsState()
    val logs by vm.logs.collectAsState()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(30_000); now = System.currentTimeMillis() } }
    val today = remember(now) { LocalDate.now().toEpochDay() }
    var selected by remember { mutableLongStateOf(LocalDate.now().toEpochDay()) }
    var weekShift by remember { mutableIntStateOf(0) }
    val h24 = vm.prefs.use24h

    val doses = remember(meds, logs, now, selected) { Repo.buildDoses(meds, logs, selected, now) }
    val done = doses.count { it.status == "TAKEN" }
    val progress = if (doses.isEmpty()) 0f else done / doses.size.toFloat()

    val todayDoses = remember(meds, logs, now) { Repo.buildDoses(meds, logs, today, now) }
    val tomorrowDoses = remember(meds, logs, now) { Repo.buildDoses(meds, logs, today + 1, now) }
    val upcoming: List<Pair<DoseItem, String>> = remember(todayDoses, tomorrowDoses) {
        (todayDoses.filter { it.status == "DUE" || it.status == "UPCOMING" }.map { it to "Today" } +
            tomorrowDoses.map { it to "Tomorrow" }).take(4)
    }
    val next = upcoming.firstOrNull()

    val tick = rememberResumeTick()
    val setupOk = remember(tick) { Perms.setupComplete(ctx) }
    val hour = remember(now) { LocalTime.now().hour }
    val greeting = when { hour < 12 -> "Good morning"; hour < 18 -> "Good afternoon"; else -> "Good evening" }
    val name = vm.prefs.userName.trim()
    val byDay = remember(logs) { logs.groupBy { it.day } }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 110.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            item {
                GradientHeader {
                    Text("MediCare", color = Color.White.copy(alpha = 0.9f), style = MaterialTheme.typography.titleMedium)
                    Text(if (name.isEmpty()) "$greeting 👋" else "$greeting, $name 👋", color = Color.White,
                        style = MaterialTheme.typography.headlineMedium)
                    Text(dayText(selected, "EEEE, MMMM d, yyyy") + if (selected == today) "  •  Today" else "",
                        color = Color.White.copy(alpha = 0.92f), style = MaterialTheme.typography.bodyLarge)
                    Spacer(Modifier.height(16.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ProgressRing(progress, 124.dp, if (doses.isEmpty()) "–" else "$done/${doses.size}", "taken")
                        Spacer(Modifier.width(20.dp))
                        Column {
                            Text("Next reminder", color = Color.White.copy(alpha = 0.9f), style = MaterialTheme.typography.bodyMedium)
                            if (next != null) {
                                Text(next.first.m.name, color = Color.White, style = MaterialTheme.typography.titleLarge)
                                Text("${next.first.m.dosage} • ${fmtTime(next.first.min, h24)}", color = Color.White,
                                    style = MaterialTheme.typography.bodyLarge)
                                Text(next.second, color = Color.White.copy(alpha = 0.9f), style = MaterialTheme.typography.bodyMedium)
                            } else {
                                Text(if (meds.isEmpty()) "Add your first medicine" else "Nothing coming up ✓", color = Color.White,
                                    style = MaterialTheme.typography.titleMedium)
                            }
                        }
                    }
                }
            }

            // interactive week calendar
            item {
                val monday = LocalDate.now().with(DayOfWeek.MONDAY).plusWeeks(weekShift.toLong())
                Card(HPad.fillMaxWidth(), shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton({ weekShift-- }) { Text("‹", fontSize = 28.sp) }
                            Text(monday.format(DateTimeFormatter.ofPattern("MMMM yyyy")), Modifier.weight(1f),
                                textAlign = TextAlign.Center, style = MaterialTheme.typography.titleMedium)
                            TextButton({ weekShift++ }) { Text("›", fontSize = 28.sp) }
                        }
                        Row(Modifier.fillMaxWidth()) {
                            for (i in 0 until 7) {
                                val date = monday.plusDays(i.toLong())
                                val ep = date.toEpochDay()
                                val isSel = ep == selected
                                val st = byDay[ep]
                                val dot = when {
                                    st == null -> Color.Transparent
                                    st.any { it.status == "MISSED" } -> Red
                                    st.all { it.status == "TAKEN" } -> Green
                                    else -> Orange
                                }
                                val bg by animateColorAsState(if (isSel) MaterialTheme.colorScheme.primary else Color.Transparent, label = "daybg")
                                val fg = if (isSel) Color.White else MaterialTheme.colorScheme.onSurface
                                Column(
                                    Modifier.weight(1f).padding(2.dp).clip(RoundedCornerShape(20.dp)).background(bg)
                                        .then(if (ep == today && !isSel) Modifier.border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(20.dp)) else Modifier)
                                        .clickable { selected = ep }.padding(vertical = 8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(date.format(DateTimeFormatter.ofPattern("EEE")), color = fg, fontSize = 13.sp)
                                    Text("${date.dayOfMonth}", color = fg, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                    Box(Modifier.size(8.dp).clip(CircleShape).background(if (isSel && dot == Color.Transparent) Color.Transparent else dot))
                                }
                            }
                        }
                    }
                }
            }

            if (!setupOk) item {
                Card(HPad.fillMaxWidth().clickable { onSettings() }, shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Warning, null, tint = Red)
                        Spacer(Modifier.width(12.dp))
                        Text("Finish setup so alarms always ring. Tap to open the Setup guide & test.",
                            color = MaterialTheme.colorScheme.onErrorContainer)
                    }
                }
            }

            if (upcoming.isNotEmpty()) item {
                Card(HPad.fillMaxWidth(), shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Upcoming reminders", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSecondaryContainer)
                        upcoming.forEach { (d, label) ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.surface) {
                                    Text(fmtTime(d.min, h24), Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                        fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
                                }
                                Spacer(Modifier.width(12.dp))
                                Text("${d.m.name} • ${d.m.dosage}", Modifier.weight(1f), color = MaterialTheme.colorScheme.onSecondaryContainer,
                                    style = MaterialTheme.typography.bodyMedium)
                                Text(label, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSecondaryContainer)
                            }
                        }
                    }
                }
            }

            item {
                Text(if (selected == today) "Today's medicines" else "Medicines on ${dayText(selected)}",
                    HPad, style = MaterialTheme.typography.titleLarge)
            }
            if (doses.isEmpty()) item {
                Text(if (meds.isEmpty()) "You haven't added any medicines yet. Tap “Add Medicine” to start." else "No medicines are scheduled for this day.",
                    HPad, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(doses, key = { "${it.day}-${it.m.id}-${it.min}" }) { d ->
                Box(HPad) {
                    DoseCard(d, h24, canAct = selected <= today,
                        onTaken = { vm.record(d, "TAKEN") }, onSkip = { vm.record(d, "SKIPPED") })
                }
            }
        }
        ExtendedFloatingActionButton(
            onClick = onAdd, modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp),
            shape = RoundedCornerShape(50), containerColor = MaterialTheme.colorScheme.primary, contentColor = Color.White
        ) {
            Icon(Icons.Filled.Add, null); Spacer(Modifier.width(8.dp)); Text("Add Medicine")
        }
    }
}

// ---------- 2. Add / Edit (with exact-minute time picker and full date picker) ----------

@Composable
fun AddEditScreen(vm: MainVM, editing: Medicine?, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val h24 = vm.prefs.use24h
    var name by remember { mutableStateOf(editing?.name ?: "") }
    var dosage by remember { mutableStateOf(editing?.dosage ?: "") }
    var freq by remember { mutableStateOf(editing?.frequency ?: "Once daily") }
    var times by remember { mutableStateOf(editing?.minuteList() ?: listOf(480)) }
    var start by remember { mutableLongStateOf(editing?.startDay ?: LocalDate.now().toEpochDay()) }
    var noEnd by remember { mutableStateOf(editing?.endDay == -1L) }
    var end by remember { mutableLongStateOf(if (editing != null && editing.endDay >= 0) editing.endDay else start + 6) }
    var notes by remember { mutableStateOf(editing?.notes ?: "") }
    var error by remember { mutableStateOf<String?>(null) }
    var timeIdx by remember { mutableIntStateOf(-1) }
    var dateTarget by remember { mutableIntStateOf(0) }   // 0 none, 1 start, 2 end
    val fieldShape = RoundedCornerShape(20.dp)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        GradientHeader {
            Text(if (editing == null) "Add Medicine" else "Edit Medicine", color = Color.White, style = MaterialTheme.typography.headlineMedium)
            Text("MediCare only reminds you. Enter the medicine and dosage exactly as prescribed by your doctor.",
                color = Color.White.copy(alpha = 0.95f), style = MaterialTheme.typography.bodyMedium)
        }
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            SectionCard("Medicine") {
                OutlinedTextField(name, { name = it }, label = { Text("Medicine name") }, singleLine = true,
                    shape = fieldShape, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(dosage, { dosage = it }, label = { Text("Prescribed dosage (e.g. 500 mg, 1 tablet)") },
                    shape = fieldShape, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(notes, { notes = it }, label = { Text("Instructions / notes (optional)") },
                    shape = fieldShape, modifier = Modifier.fillMaxWidth(), minLines = 2)
            }

            SectionCard("How often?") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScrollCompat()) {
                    listOf("Once daily", "Twice daily", "Three times daily", "Custom").forEach { f ->
                        FilterChip(selected = freq == f, onClick = {
                            freq = f
                            when (f) {
                                "Once daily" -> times = listOf(480)
                                "Twice daily" -> times = listOf(480, 1200)
                                "Three times daily" -> times = listOf(480, 840, 1200)
                            }
                        }, label = { Text(f, fontSize = 16.sp) })
                    }
                }
                Text("Reminder times — tap a time to set ANY exact minute", style = MaterialTheme.typography.bodyMedium)
                times.forEachIndexed { i, t ->
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton({ timeIdx = i }, Modifier.weight(1f).heightIn(min = 64.dp), shape = RoundedCornerShape(24.dp)) {
                            Text("⏰  " + fmtTime(t, h24), fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        }
                        if (times.size > 1) TextButton({ times = times.filterIndexed { idx, _ -> idx != i }; freq = "Custom" }) { Text("Remove") }
                    }
                }
                OutlinedButton({ times = times + 720; freq = "Custom" }, Modifier.heightIn(min = 52.dp), shape = RoundedCornerShape(50)) {
                    Text("+ Add another time")
                }
            }

            SectionCard("Dates") {
                FilledTonalButton({ dateTarget = 1 }, Modifier.fillMaxWidth().heightIn(min = 60.dp), shape = RoundedCornerShape(24.dp)) {
                    Text("📅  Start: ${dayText(start, "MMM d, yyyy")}", fontSize = 20.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(noEnd, { noEnd = it }); Text("No end date (ongoing)")
                }
                if (!noEnd) FilledTonalButton({ dateTarget = 2 }, Modifier.fillMaxWidth().heightIn(min = 60.dp), shape = RoundedCornerShape(24.dp)) {
                    Text("📅  End: ${dayText(end, "MMM d, yyyy")}", fontSize = 20.sp)
                }
            }

            error?.let { Text(it, color = Red, fontWeight = FontWeight.Bold) }
            BigButton("Save Medicine", Modifier.fillMaxWidth()) {
                val distinct = times.distinct().sorted()
                error = when {
                    name.isBlank() -> "Please enter the medicine name."
                    dosage.isBlank() -> "Please enter the dosage prescribed by your doctor."
                    distinct.isEmpty() -> "Please add at least one reminder time."
                    !noEnd && end < start -> "The end date must not be before the start date."
                    else -> null
                }
                if (error == null) {
                    vm.save(Medicine(
                        id = editing?.id ?: 0, name = name.trim(), dosage = dosage.trim(), frequency = freq,
                        times = distinct.joinToString(","), startDay = start,
                        endDay = if (noEnd) -1 else end, notes = notes.trim(),
                        createdAt = System.currentTimeMillis()))
                    Toast.makeText(ctx, "Saved. Reminders are set.", Toast.LENGTH_SHORT).show()
                    onDone()
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (timeIdx in times.indices) {
        val idx = timeIdx
        TimePickDialog(times[idx], h24, onDismiss = { timeIdx = -1 }) { v ->
            times = times.toMutableList().also { it[idx] = v }
            timeIdx = -1
        }
    }
    if (dateTarget != 0) {
        val target = dateTarget
        DatePickDialog(if (target == 1) start else end, onDismiss = { dateTarget = 0 }) { day ->
            if (target == 1) { start = day; if (!noEnd && end < start) end = start } else end = day
            dateTarget = 0
        }
    }
}

/**
 * Time picker where ANY minute 00–59 can be typed or stepped (1 minute at a time).
 * Supports AM/PM (12-hour) or 24-hour mode, with live validation.
 */
@Composable
fun TimePickDialog(initial: Int, h24: Boolean, onDismiss: () -> Unit, onConfirm: (Int) -> Unit) {
    val h0 = initial / 60
    var hText by remember { mutableStateOf(if (h24) "%02d".format(h0) else (if (h0 % 12 == 0) 12 else h0 % 12).toString()) }
    var mText by remember { mutableStateOf("%02d".format(initial % 60)) }
    var pm by remember { mutableStateOf(h0 >= 12) }

    val hv = hText.toIntOrNull()
    val mv = mText.toIntOrNull()
    val hourOk = hv != null && (if (h24) hv in 0..23 else hv in 1..12)
    val minOk = mv != null && mv in 0..59
    val valid = hourOk && minOk

    fun stepHour(d: Int) {
        val cur = hv ?: if (h24) 0 else 12
        val n = if (h24) (cur + d + 24) % 24 else ((cur - 1 + d + 12) % 12) + 1
        hText = if (h24) "%02d".format(n) else n.toString()
    }
    fun stepMinute(d: Int) {
        val cur = mv ?: 0
        mText = "%02d".format((cur + d + 60) % 60)
    }
    fun result(): Int {
        val h = hv ?: 0
        val hour24 = if (h24) h else (h % 12) + (if (pm) 12 else 0)
        return hour24 * 60 + (mv ?: 0)
    }
    val numberStyle = LocalTextStyle.current.copy(fontSize = 38.sp, textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(32.dp),
        title = { Text("Set reminder time") },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        TextButton({ stepHour(1) }) { Text("▲", fontSize = 22.sp) }
                        OutlinedTextField(hText, { hText = it.filter { c -> c.isDigit() }.take(2) },
                            Modifier.width(96.dp).heightIn(min = 84.dp), textStyle = numberStyle, singleLine = true, isError = !hourOk,
                            shape = RoundedCornerShape(20.dp), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                        TextButton({ stepHour(-1) }) { Text("▼", fontSize = 22.sp) }
                        Text("hour", fontSize = 14.sp)
                    }
                    Text(":", fontSize = 40.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        TextButton({ stepMinute(1) }) { Text("▲", fontSize = 22.sp) }
                        OutlinedTextField(mText, { mText = it.filter { c -> c.isDigit() }.take(2) },
                            Modifier.width(96.dp).heightIn(min = 84.dp), textStyle = numberStyle, singleLine = true, isError = !minOk,
                            shape = RoundedCornerShape(20.dp), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                        TextButton({ stepMinute(-1) }) { Text("▼", fontSize = 22.sp) }
                        Text("minute", fontSize = 14.sp)
                    }
                }
                if (!h24) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        FilterChip(!pm, { pm = false }, label = { Text("AM", fontSize = 20.sp) })
                        FilterChip(pm, { pm = true }, label = { Text("PM", fontSize = 20.sp) })
                    }
                }
                if (valid) Text("Reminder at " + fmtTime(result(), h24), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                else Text(if (h24) "Hour 0–23, minute 00–59" else "Hour 1–12, minute 00–59", color = Red)
                Text("Type any exact time, such as 2:12 or 8:43.", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = { TextButton({ if (valid) onConfirm(result()) }, enabled = valid) { Text("OK", fontSize = 20.sp) } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel", fontSize = 20.sp) } }
    )
}

/** Material 3 calendar: swipe/tap between months and years, or switch to keyboard entry with the pencil icon. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DatePickDialog(initialDay: Long, onDismiss: () -> Unit, onConfirm: (Long) -> Unit) {
    val state = rememberDatePickerState(initialSelectedDateMillis = initialDay * 86_400_000L)
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton({ state.selectedDateMillis?.let { onConfirm(Math.floorDiv(it, 86_400_000L)) } ?: onDismiss() }) {
                Text("OK", fontSize = 20.sp)
            }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancel", fontSize = 20.sp) } }
    ) { DatePicker(state = state, showModeToggle = true) }
}

// ---------- 3. My Medicines ----------

@Composable
fun MyMedicinesScreen(vm: MainVM, onEdit: (Medicine) -> Unit, onAdd: () -> Unit) {
    val meds by vm.medicines.collectAsState()
    var toDelete by remember { mutableStateOf<Medicine?>(null) }
    val h24 = vm.prefs.use24h

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            GradientHeader {
                Text("My Medicines", color = Color.White, style = MaterialTheme.typography.headlineMedium)
                Text(if (meds.isEmpty()) "Nothing added yet" else "${meds.size} medicine${if (meds.size == 1) "" else "s"} scheduled",
                    color = Color.White.copy(alpha = 0.95f), style = MaterialTheme.typography.bodyLarge)
            }
        }
        if (meds.isEmpty()) {
            item { Text("You haven't added any medicines yet.", HPad, style = MaterialTheme.typography.bodyLarge) }
            item { BigButton("+ Add Medicine", HPad.fillMaxWidth(), onClick = onAdd) }
        }
        items(meds, key = { it.id }) { m ->
            Card(HPad.fillMaxWidth().animateContentSize(), shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(56.dp).clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.secondaryContainer),
                            contentAlignment = Alignment.Center) {
                            Text(m.name.take(1).uppercase(), fontSize = 26.sp, fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer)
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(m.name, style = MaterialTheme.typography.titleMedium)
                            Text("Dosage: ${m.dosage}", style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Text("${m.frequency} • ${m.minuteList().joinToString(", ") { fmtTime(it, h24) }}", style = MaterialTheme.typography.bodyMedium)
                    Text("${dayText(m.startDay, "MMM d, yyyy")} → " + if (m.endDay < 0) "ongoing" else dayText(m.endDay, "MMM d, yyyy"),
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (m.notes.isNotBlank()) Text("Notes: ${m.notes}", style = MaterialTheme.typography.bodyMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        FilledTonalButton({ onEdit(m) }, Modifier.weight(1f).heightIn(min = 52.dp), shape = RoundedCornerShape(50)) {
                            Icon(Icons.Filled.Edit, null); Spacer(Modifier.width(6.dp)); Text("Edit")
                        }
                        OutlinedButton({ toDelete = m }, Modifier.weight(1f).heightIn(min = 52.dp), shape = RoundedCornerShape(50)) {
                            Icon(Icons.Filled.Delete, null, tint = Red); Spacer(Modifier.width(6.dp)); Text("Delete", color = Red)
                        }
                    }
                }
            }
        }
    }
    toDelete?.let { m ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            shape = RoundedCornerShape(28.dp),
            title = { Text("Delete ${m.name}?") },
            text = { Text("Its reminders will be cancelled. Past history stays in Monitoring.") },
            confirmButton = { TextButton({ vm.delete(m); toDelete = null }) { Text("Delete", color = Red) } },
            dismissButton = { TextButton({ toDelete = null }) { Text("Cancel") } }
        )
    }
}

// ---------- 4. Monitoring ----------

@Composable
fun MonitoringScreen(vm: MainVM) {
    val logs by vm.logs.collectAsState()
    val h24 = vm.prefs.use24h
    var month by remember { mutableStateOf(YearMonth.now()) }
    var selected by remember { mutableLongStateOf(LocalDate.now().toEpochDay()) }
    var weekly by remember { mutableStateOf(false) }

    val from = if (weekly) selected - 6 else selected
    val range = remember(logs, from, selected) { logs.filter { it.day in from..selected } }
    val taken = range.count { it.status == "TAKEN" }
    val missed = range.count { it.status == "MISSED" }
    val skipped = range.count { it.status == "SKIPPED" }
    val total = taken + missed + skipped
    val adherence = if (total == 0) null else taken * 100 / total
    val byDay = remember(logs) { logs.groupBy { it.day } }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            GradientHeader {
                Text("Monitoring", color = Color.White, style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ProgressRing((adherence ?: 0) / 100f, 124.dp, if (adherence == null) "–" else "$adherence%", "adherence")
                    Spacer(Modifier.width(20.dp))
                    Column {
                        Text(if (weekly) "${dayText(from)} – ${dayText(selected)}" else dayText(selected, "EEEE, MMM d"),
                            color = Color.White, style = MaterialTheme.typography.titleMedium)
                        Text("Taken ÷ (Taken + Missed + Skipped)", color = Color.White.copy(alpha = 0.9f), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        item {
            Row(HPad, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(!weekly, { weekly = false }, label = { Text("Daily", fontSize = 17.sp) })
                FilterChip(weekly, { weekly = true }, label = { Text("Weekly (7 days)", fontSize = 17.sp) })
            }
        }
        item {
            Row(HPad, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatBox("Taken", taken, Green, Modifier.weight(1f))
                StatBox("Missed", missed, Red, Modifier.weight(1f))
                StatBox("Skipped", skipped, Grey, Modifier.weight(1f))
            }
        }
        item {
            Card(HPad.fillMaxWidth(), shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton({ month = month.minusMonths(1) }) { Text("‹", fontSize = 32.sp) }
                        Text(month.format(DateTimeFormatter.ofPattern("MMMM yyyy")), Modifier.weight(1f),
                            textAlign = TextAlign.Center, style = MaterialTheme.typography.titleMedium)
                        TextButton({ month = month.plusMonths(1) }) { Text("›", fontSize = 32.sp) }
                    }
                    Row(Modifier.fillMaxWidth()) {
                        listOf("S", "M", "T", "W", "T", "F", "S").forEach {
                            Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
                        }
                    }
                    val offset = month.atDay(1).dayOfWeek.value % 7
                    val days = month.lengthOfMonth()
                    val todayEpoch = LocalDate.now().toEpochDay()
                    for (week in 0 until 6) {
                        if (week * 7 - offset + 1 > days) break
                        Row(Modifier.fillMaxWidth()) {
                            for (dow in 0 until 7) {
                                val n = week * 7 + dow - offset + 1
                                if (n < 1 || n > days) {
                                    Spacer(Modifier.weight(1f).height(50.dp))
                                } else {
                                    val ep = month.atDay(n).toEpochDay()
                                    val st = byDay[ep]
                                    val dot = when {
                                        st == null -> Color.Transparent
                                        st.any { it.status == "MISSED" } -> Red
                                        st.all { it.status == "TAKEN" } -> Green
                                        else -> Orange
                                    }
                                    Box(Modifier.weight(1f).height(50.dp).padding(2.dp).clip(RoundedCornerShape(16.dp))
                                        .background(if (ep == selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                                        .clickable { selected = ep }, contentAlignment = Alignment.Center) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text("$n", fontWeight = if (ep == todayEpoch) FontWeight.ExtraBold else FontWeight.Normal,
                                                color = if (ep == todayEpoch) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                                            Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
                                        }
                                    }
                                }
                            }
                        }
                    }
                    Text("● green: all taken   ● orange: some skipped   ● red: missed", style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
        item { Text("History", HPad, style = MaterialTheme.typography.titleLarge) }
        if (range.isEmpty()) item { Text("Nothing recorded for this period.", HPad, style = MaterialTheme.typography.bodyLarge) }
        items(range.sortedWith(compareByDescending<DoseLog> { it.day }.thenByDescending { it.minutes }), key = { it.id }) { l ->
            Card(HPad.fillMaxWidth(), shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(l.medicineName, style = MaterialTheme.typography.titleMedium)
                        Text("${if (weekly) dayText(l.day) + " • " else ""}${fmtTime(l.minutes, h24)} • ${l.dosage}",
                            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    StatusChip(l.status)
                }
            }
        }
    }
}

@Composable
private fun StatBox(label: String, n: Int, color: Color, modifier: Modifier) {
    Card(modifier, shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.13f))) {
        Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$n", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = color)
            Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

// ---------- 5. Settings, setup guide, diagnostics ----------

@Composable
fun SettingsScreen(vm: MainVM) {
    val ctx = LocalContext.current
    val p = vm.prefs

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data ?: return@rememberLauncherForActivityResult
        val uri = IntentCompat.getParcelableExtra(data, RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
        p.soundUri = uri?.toString() ?: ""
        p.save()
    }
    val soundName = remember(p.soundUri) {
        try {
            val u = if (p.soundUri.isEmpty()) RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) else Uri.parse(p.soundUri)
            RingtoneManager.getRingtone(ctx, u)?.getTitle(ctx) ?: "Default alarm"
        } catch (e: Exception) { "Default alarm" }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        GradientHeader {
            Text("Settings", color = Color.White, style = MaterialTheme.typography.headlineMedium)
            Text("MediCare", color = Color.White.copy(alpha = 0.95f), style = MaterialTheme.typography.titleMedium)
        }
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            SectionCard("Profile") {
                OutlinedTextField(p.userName, { p.userName = it; p.save() }, label = { Text("Your name (for greetings)") },
                    singleLine = true, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth())
            }

            SectionCard("Alarm & notifications") {
                SwitchRow("Alarm sound", p.sound) { p.sound = it; p.save() }
                SwitchRow("Vibration", p.vibrate) { p.vibrate = it; p.save() }
                SwitchRow("Show medicine details on lock screen", p.lockScreen) { p.lockScreen = it; p.save() }
                Text("Sound: $soundName", style = MaterialTheme.typography.bodyLarge)
                FilledTonalButton({
                    picker.launch(Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                        .putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM or RingtoneManager.TYPE_NOTIFICATION or RingtoneManager.TYPE_RINGTONE)
                        .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                        .putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI,
                            if (p.soundUri.isEmpty()) null else Uri.parse(p.soundUri)))
                }, Modifier.heightIn(min = 52.dp), shape = RoundedCornerShape(50)) { Text("Choose sound") }
                Text("Snooze duration", style = MaterialTheme.typography.bodyLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScrollCompat()) {
                    listOf(5, 10, 15, 20, 30).forEach { m ->
                        FilterChip(p.snoozeMin == m, { p.snoozeMin = m; p.save() }, label = { Text("$m min", fontSize = 16.sp) })
                    }
                }
            }

            SectionCard("Display") {
                Text("Time format", style = MaterialTheme.typography.bodyLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(!p.use24h, { p.use24h = false; p.save() }, label = { Text("12-hour (AM/PM)", fontSize = 16.sp) })
                    FilterChip(p.use24h, { p.use24h = true; p.save() }, label = { Text("24-hour", fontSize = 16.sp) })
                }
                Text("Theme", style = MaterialTheme.typography.bodyLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("System", "Light", "Dark").forEachIndexed { i, label ->
                        FilterChip(p.theme == i, { p.theme = i; p.save() }, label = { Text(label, fontSize = 16.sp) })
                    }
                }
            }

            SetupGuideCard()
            DiagnosticsCard(vm)
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SetupGuideCard() {
    val ctx = LocalContext.current
    SectionCard("Setup guide for reliable alarms") {
        Text("Android and phone makers (Nubia, Xiaomi, Oppo, Vivo, Huawei, Samsung…) can stop apps in the background to save battery. " +
            "MediCare uses the most reliable alarm type Android offers, but it cannot override your phone's own rules. " +
            "Please do these steps once:", style = MaterialTheme.typography.bodyMedium)
        listOf(
            "1. Allow Notifications for MediCare.",
            "2. Set Battery to “Unrestricted” / “No restrictions” / “Don't optimize” (use the checks below).",
            "3. Turn on Autostart / “Allow background activity” / “Never sleeping apps” for MediCare in your phone's Settings or Security app.",
            "4. Open Recents, then Lock MediCare (long-press its card > Lock). Never use “Force stop” or “Clean all”.",
            "5. Keep alarm volume up and don't leave the phone in a mode that blocks alarms.",
            "6. Run the tests below and confirm they ring while the screen is off."
        ).forEach { Text(it, style = MaterialTheme.typography.bodyMedium) }
        FilledTonalButton({
            try {
                ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) { Toast.makeText(ctx, "Open Settings > Apps > MediCare", Toast.LENGTH_LONG).show() }
        }, Modifier.heightIn(min = 52.dp), shape = RoundedCornerShape(50)) { Text("Open MediCare app info") }
    }
}

private data class Check(
    val level: Int, val title: String, val detail: String,
    val fixLabel: String? = null, val fix: (() -> Unit)? = null
)

@Composable
private fun DiagnosticsCard(vm: MainVM) {
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    var refresh by remember { mutableIntStateOf(0) }
    val meds by vm.medicines.collectAsState()
    var reg by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    LaunchedEffect(tick, refresh, meds) {
        delay(300)
        reg = withContext(Dispatchers.IO) { AlarmScheduler.registeredCount(ctx) }
    }

    fun open(i: Intent) {
        try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { Toast.makeText(ctx, "Could not open that screen. Open Settings > Apps > MediCare instead.", Toast.LENGTH_LONG).show() }
    }
    val pkgUri = Uri.parse("package:${ctx.packageName}")

    val checks = remember(tick, refresh, vm.prefs.sound, reg) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val list = mutableListOf<Check>()
        list += if (Perms.notificationsOn(ctx)) Check(0, "Notifications are allowed", "MediCare can show reminders.")
        else Check(2, "Notifications are blocked", "Reminders cannot appear until you allow them.", "Open notification settings") {
            open(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName))
        }
        list += if (Perms.channelOk(ctx)) Check(0, "Alarm notification channel is on", "High-importance channel is active.")
        else Check(2, "Alarm channel is turned off", "Turn “Medicine alarms” back on.", "Open channel settings") {
            open(Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                .putExtra(Settings.EXTRA_CHANNEL_ID, Notifier.CH))
        }
        list += if (Perms.batteryExempt(ctx)) Check(0, "Battery: unrestricted", "Android will not put MediCare to sleep.")
        else Check(1, "Battery optimization may stop alarms", "Allow MediCare to run without battery restrictions.", "Allow now") {
            open(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkgUri))
        }
        if (Build.VERSION.SDK_INT >= 34 && !Perms.fullScreenOk(ctx))
            list += Check(1, "Full-screen alarm is not allowed", "The alarm will show as a notification only on the lock screen.", "Allow") {
                open(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, pkgUri))
            }
        list += if (Perms.exactOk(ctx)) Check(0, "Exact alarms are allowed", "Alarms fire at the exact minute.")
        else Check(0, "Alarm-clock mode in use", "Exact-alarm permission is off, but MediCare uses Android's alarm-clock type, which is still exact (an ⏰ icon shows in the status bar).",
            if (Build.VERSION.SDK_INT >= 31) "Allow exact alarms" else null,
            if (Build.VERSION.SDK_INT >= 31) ({ open(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkgUri)) }) else null)
        val vol = ctx.getSystemService(AudioManager::class.java).getStreamVolume(AudioManager.STREAM_ALARM)
        list += if (vol > 0) Check(0, "Alarm volume is on", "Alarm volume level: $vol.")
        else Check(2, "Alarm volume is 0", "Raise the alarm volume in your phone's Sound settings, or you won't hear alarms.")
        if (nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL)
            list += Check(1, "Do Not Disturb is on", "Alarms are usually still allowed, but check your Do Not Disturb settings.")
        if (ctx.getSystemService(PowerManager::class.java).isPowerSaveMode)
            list += Check(1, "Battery saver is on", "It can delay or block background alarms. Turn it off for medicine reminders.", "Open battery saver") {
                open(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
            }
        if (!vm.prefs.sound) list += Check(1, "Alarm sound is switched off in MediCare", "Only vibration and the notification will be used.")
        reg?.let { (r, e) ->
            list += when {
                e == 0 -> Check(0, "No alarms needed yet", "Add a medicine to schedule reminders.")
                r == e -> Check(0, "All $e reminder alarms are registered", "Android has every upcoming reminder scheduled.")
                else -> Check(2, "Only $r of $e alarms are registered", "Some reminders are missing. Re-register them now.", "Re-register alarms") {
                    vm.refresh(); refresh++
                }
            }
        }
        list.toList()
    }

    SectionCard("Alarm & notification check") {
        Text("Verify that your phone is set up correctly. Green is good; fix any ⚠️ or ❌ items.", style = MaterialTheme.typography.bodyMedium)
        checks.forEach { c ->
            Row(verticalAlignment = Alignment.Top) {
                Text(when (c.level) { 0 -> "✅"; 1 -> "⚠️"; else -> "❌" }, fontSize = 22.sp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(c.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    Text(c.detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    val fx = c.fix; val fl = c.fixLabel
                    if (fx != null && fl != null) TextButton(fx) { Text(fl, fontWeight = FontWeight.Bold) }
                }
            }
        }
        Text("Tests", style = MaterialTheme.typography.titleMedium)
        FilledTonalButton({
            Notifier.postTest(ctx)
            Toast.makeText(ctx, "Test notification sent. Pull down the notification panel.", Toast.LENGTH_SHORT).show()
        }, Modifier.fillMaxWidth().heightIn(min = 52.dp), shape = RoundedCornerShape(50)) { Text("Send test notification now") }
        FilledTonalButton({
            AlarmScheduler.scheduleTest(ctx, 10)
            Toast.makeText(ctx, "Alarm in 10 seconds. You can close the app.", Toast.LENGTH_LONG).show()
        }, Modifier.fillMaxWidth().heightIn(min = 52.dp), shape = RoundedCornerShape(50)) { Text("Test alarm in 10 seconds") }
        FilledTonalButton({
            AlarmScheduler.scheduleTest(ctx, 60)
            Toast.makeText(ctx, "Alarm in 1 minute. Remove MediCare from Recents and lock the phone.", Toast.LENGTH_LONG).show()
        }, Modifier.fillMaxWidth().heightIn(min = 52.dp), shape = RoundedCornerShape(50)) { Text("Test alarm in 1 minute (app closed)") }
        OutlinedButton({
            vm.refresh(); refresh++
            Toast.makeText(ctx, "All alarms re-registered.", Toast.LENGTH_SHORT).show()
        }, Modifier.fillMaxWidth().heightIn(min = 52.dp), shape = RoundedCornerShape(50)) { Text("Re-register all alarms") }
    }
}
