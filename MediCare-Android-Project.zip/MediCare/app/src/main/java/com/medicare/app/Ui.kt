package com.medicare.app

import android.Manifest
import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter

private val Green = Color(0xFF2E9E5B)
private val Red = Color(0xFFD64545)
private val Grey = Color(0xFF7A8A96)
private val Orange = Color(0xFFE08A00)
private val Blue = Color(0xFF2B7BB9)

private fun statusInfo(s: String): Pair<String, Color> = when (s) {
    "TAKEN" -> "Taken" to Green
    "MISSED" -> "Missed" to Red
    "SKIPPED" -> "Skipped" to Grey
    "DUE" -> "Due now" to Orange
    else -> "Upcoming" to Blue
}

private fun dayText(epoch: Long, pattern: String = "EEE, MMM d") =
    LocalDate.ofEpochDay(epoch).format(DateTimeFormatter.ofPattern(pattern))

@Composable
fun rememberResumeTick(): Int {
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    return tick
}

// ---------- shared pieces ----------

@Composable
fun StatusChip(status: String) {
    val (text, color) = statusInfo(status)
    Surface(color = color.copy(alpha = 0.15f), shape = RoundedCornerShape(50)) {
        Text(text, color = color, fontWeight = FontWeight.Bold, fontSize = 16.sp,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp))
    }
}

@Composable
fun BigButton(text: String, modifier: Modifier = Modifier, color: Color? = null, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.heightIn(min = 56.dp),
        shape = RoundedCornerShape(16.dp),
        colors = if (color != null) ButtonDefaults.buttonColors(containerColor = color) else ButtonDefaults.buttonColors()
    ) { Text(text) }
}

@Composable
fun DoseCard(d: DoseItem, h24: Boolean, onTaken: () -> Unit, onSkip: () -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(d.m.name, style = MaterialTheme.typography.titleMedium)
                    Text("Dosage: ${d.m.dosage}", style = MaterialTheme.typography.bodyLarge)
                }
                StatusChip(d.status)
            }
            Text(fmtTime(d.min, h24), style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
            if (d.m.notes.isNotBlank()) Text(d.m.notes, style = MaterialTheme.typography.bodyMedium)
            if (d.status == "UPCOMING" || d.status == "DUE" || d.status == "MISSED") {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    BigButton("Taken", Modifier.weight(1f), Green, onTaken)
                    OutlinedButton(onSkip, Modifier.weight(1f).heightIn(min = 56.dp), shape = RoundedCornerShape(16.dp)) { Text("Skip") }
                }
            }
        }
    }
}

// ---------- root ----------

@Composable
fun MediCareRoot(vm: MainVM) {
    val dark = when (vm.prefs.theme) { 1 -> false; 2 -> true; else -> androidx.compose.foundation.isSystemInDarkTheme() }
    MediCareTheme(dark) {
        var splash by remember { mutableStateOf(true) }
        LaunchedEffect(Unit) { delay(1300); splash = false }
        if (splash) Splash() else MainScaffold(vm)
    }
}

@Composable
fun Splash() {
    Column(
        Modifier.fillMaxSize().background(Color(0xFF2B7BB9)),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(painterResource(R.drawable.ic_launcher_foreground), null, Modifier.size(180.dp))
        Text("MediCare", color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.Bold)
        Text("Medicine Reminder & Monitoring System", color = Color.White.copy(alpha = 0.9f),
            fontSize = 17.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 32.dp, vertical = 8.dp))
    }
}

@Composable
fun MainScaffold(vm: MainVM) {
    val ctx = LocalContext.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<Medicine?>(null) }
    var formKey by remember { mutableIntStateOf(0) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    val items = listOf("Home" to Icons.Filled.Home, "Add Medicine" to Icons.Filled.Add,
        "My Medicines" to Icons.Filled.Menu, "Monitoring" to Icons.Filled.DateRange, "Settings" to Icons.Filled.Settings)

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar {
                items.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { if (i == 1 && tab != 1) { editing = null; formKey++ }; tab = i },
                        icon = { Icon(icon, label) },
                        label = { Text(label, fontSize = 11.sp, maxLines = 2, textAlign = TextAlign.Center, lineHeight = 13.sp) },
                        alwaysShowLabel = true
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen(vm, onAdd = { editing = null; formKey++; tab = 1 }, onSettings = { tab = 4 })
                1 -> key(formKey) { AddEditScreen(vm, editing) { editing = null; formKey++; tab = 2 } }
                2 -> MyMedicinesScreen(vm, onEdit = { editing = it; formKey++; tab = 1 }, onAdd = { editing = null; formKey++; tab = 1 })
                3 -> MonitoringScreen(vm)
                else -> SettingsScreen(vm)
            }
        }
    }
}

// ---------- 1. Home ----------

@Composable
fun HomeScreen(vm: MainVM, onAdd: () -> Unit, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val meds by vm.medicines.collectAsState()
    val logs by vm.logs.collectAsState()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(30_000); now = System.currentTimeMillis(); vm.refresh() } }
    val today = remember(now) { LocalDate.now().toEpochDay() }
    val doses = remember(meds, logs, now) { Repo.buildDoses(meds, logs, today, now) }
    val next = doses.firstOrNull { it.status == "DUE" || it.status == "UPCOMING" }
    val tick = rememberResumeTick()
    val permsOk = remember(tick) { Perms.notificationsOn(ctx) && Perms.exactOk(ctx) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("MediCare", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
            Text(LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy")), style = MaterialTheme.typography.titleMedium)
        }
        if (!permsOk) item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                modifier = Modifier.fillMaxWidth().clickable { onSettings() }) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Warning, null, tint = Red)
                    Spacer(Modifier.width(12.dp))
                    Text("Alarms may be late or silent. Tap here to fix notification / alarm permissions.",
                        color = MaterialTheme.colorScheme.onErrorContainer)
                }
            }
        }
        if (next != null) item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Next reminder", style = MaterialTheme.typography.bodyMedium)
                    Text("${next.m.name} • ${next.m.dosage}", style = MaterialTheme.typography.titleMedium)
                    Text("at ${fmtTime(next.min, vm.prefs.use24h)}", style = MaterialTheme.typography.titleLarge)
                }
            }
        }
        item { Text("Today's medicines", style = MaterialTheme.typography.titleLarge) }
        if (doses.isEmpty()) item {
            Text("No medicines are scheduled for today.", style = MaterialTheme.typography.bodyLarge)
        }
        items(doses, key = { "${it.m.id}-${it.min}" }) { d ->
            DoseCard(d, vm.prefs.use24h, onTaken = { vm.record(d, "TAKEN") }, onSkip = { vm.record(d, "SKIPPED") })
        }
        item { BigButton("+ Add Medicine", Modifier.fillMaxWidth(), onClick = onAdd) }
    }
}

// ---------- 2. Add / Edit ----------

@Composable
fun AddEditScreen(vm: MainVM, editing: Medicine?, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val h24 = vm.prefs.use24h
    var name by remember { mutableStateOf(editing?.name ?: "") }
    var dosage by remember { mutableStateOf(editing?.dosage ?: "") }
    var freq by remember { mutableStateOf(editing?.frequency ?: "Once daily") }
    var times by remember { mutableStateOf(editing?.minuteList() ?: listOf(480)) }
    var start by remember { mutableLongStateOf(editing?.startDay ?: LocalDate.now().toEpochDay()) }
    var noEnd by remember { mutableStateOf(editing?.endDay == -1L) }
    var end by remember { mutableLongStateOf(if (editing != null && editing.endDay >= 0) editing.endDay else start + 6) }
    var notes by remember { mutableStateOf(editing?.notes ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    fun pickTime(current: Int, onPick: (Int) -> Unit) {
        TimePickerDialog(ctx, { _, h, m -> onPick(h * 60 + m) }, current / 60, current % 60, h24).show()
    }
    fun pickDate(current: Long, onPick: (Long) -> Unit) {
        val d = LocalDate.ofEpochDay(current)
        DatePickerDialog(ctx, { _, y, mo, dd -> onPick(LocalDate.of(y, mo + 1, dd).toEpochDay()) },
            d.year, d.monthValue - 1, d.dayOfMonth).show()
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(if (editing == null) "Add Medicine" else "Edit Medicine", style = MaterialTheme.typography.headlineMedium)
        Text("MediCare only reminds you. Enter the medicine and dosage exactly as prescribed by your doctor.",
            style = MaterialTheme.typography.bodyMedium)

        OutlinedTextField(name, { name = it }, label = { Text("Medicine name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(dosage, { dosage = it }, label = { Text("Prescribed dosage (e.g. 500 mg, 1 tablet)") }, modifier = Modifier.fillMaxWidth())

        Text("How often?", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScrollCompat()) {
            listOf("Once daily", "Twice daily", "Three times daily", "Custom").forEach { f ->
                FilterChip(selected = freq == f, onClick = {
                    freq = f
                    when (f) {
                        "Once daily" -> times = listOf(480)
                        "Twice daily" -> times = listOf(480, 1200)
                        "Three times daily" -> times = listOf(480, 840, 1200)
                    }
                }, label = { Text(f, fontSize = 16.sp) })
            }
        }

        Text("Reminder times", style = MaterialTheme.typography.titleMedium)
        times.forEachIndexed { i, t ->
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({ pickTime(t) { new -> times = times.toMutableList().also { it[i] = new } } },
                    Modifier.weight(1f).heightIn(min = 56.dp), shape = RoundedCornerShape(16.dp)) { Text(fmtTime(t, h24)) }
                if (freq == "Custom" && times.size > 1)
                    TextButton({ times = times.filterIndexed { idx, _ -> idx != i } }) { Text("Remove") }
            }
        }
        if (freq == "Custom") OutlinedButton({ times = times + 720 }, Modifier.heightIn(min = 52.dp)) { Text("+ Add another time") }

        Text("Schedule dates", style = MaterialTheme.typography.titleMedium)
        OutlinedButton({ pickDate(start) { start = it } }, Modifier.fillMaxWidth().heightIn(min = 56.dp), shape = RoundedCornerShape(16.dp)) {
            Text("Start: ${dayText(start, "MMM d, yyyy")}")
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(noEnd, { noEnd = it }); Text("No end date (ongoing)")
        }
        if (!noEnd) OutlinedButton({ pickDate(end) { end = it } }, Modifier.fillMaxWidth().heightIn(min = 56.dp), shape = RoundedCornerShape(16.dp)) {
            Text("End: ${dayText(end, "MMM d, yyyy")}")
        }

        OutlinedTextField(notes, { notes = it }, label = { Text("Instructions / notes (optional)") }, modifier = Modifier.fillMaxWidth(), minLines = 2)

        error?.let { Text(it, color = Red, fontWeight = FontWeight.Bold) }
        BigButton("Save Medicine", Modifier.fillMaxWidth()) {
            error = when {
                name.isBlank() -> "Please enter the medicine name."
                dosage.isBlank() -> "Please enter the dosage prescribed by your doctor."
                times.isEmpty() -> "Please add at least one reminder time."
                !noEnd && end < start -> "The end date must not be before the start date."
                else -> null
            }
            if (error == null) {
                vm.save(Medicine(
                    id = editing?.id ?: 0, name = name.trim(), dosage = dosage.trim(), frequency = freq,
                    times = times.distinct().sorted().joinToString(","), startDay = start,
                    endDay = if (noEnd) -1 else end, notes = notes.trim(),
                    createdAt = System.currentTimeMillis()))
                Toast.makeText(ctx, "Saved. Reminders are set.", Toast.LENGTH_SHORT).show()
                onDone()
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Modifier.horizontalScrollCompat(): Modifier = this.then(Modifier.horizontalScroll(rememberScrollState()))

// ---------- 3. My Medicines ----------

@Composable
fun MyMedicinesScreen(vm: MainVM, onEdit: (Medicine) -> Unit, onAdd: () -> Unit) {
    val meds by vm.medicines.collectAsState()
    var toDelete by remember { mutableStateOf<Medicine?>(null) }
    val h24 = vm.prefs.use24h

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("My Medicines", style = MaterialTheme.typography.headlineMedium) }
        if (meds.isEmpty()) {
            item { Text("You haven't added any medicines yet.", style = MaterialTheme.typography.bodyLarge) }
            item { BigButton("+ Add Medicine", Modifier.fillMaxWidth(), onClick = onAdd) }
        }
        items(meds, key = { it.id }) { m ->
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(m.name, style = MaterialTheme.typography.titleMedium)
                    Text("Dosage: ${m.dosage}", style = MaterialTheme.typography.bodyLarge)
                    Text("${m.frequency} at ${m.minuteList().joinToString(", ") { fmtTime(it, h24) }}", style = MaterialTheme.typography.bodyMedium)
                    Text("${dayText(m.startDay, "MMM d, yyyy")} → " + if (m.endDay < 0) "ongoing" else dayText(m.endDay, "MMM d, yyyy"),
                        style = MaterialTheme.typography.bodyMedium)
                    if (m.notes.isNotBlank()) Text("Notes: ${m.notes}", style = MaterialTheme.typography.bodyMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton({ onEdit(m) }, Modifier.weight(1f).heightIn(min = 52.dp)) {
                            Icon(Icons.Filled.Edit, null); Spacer(Modifier.width(6.dp)); Text("Edit")
                        }
                        OutlinedButton({ toDelete = m }, Modifier.weight(1f).heightIn(min = 52.dp)) {
                            Icon(Icons.Filled.Delete, null, tint = Red); Spacer(Modifier.width(6.dp)); Text("Delete", color = Red)
                        }
                    }
                }
            }
        }
    }
    toDelete?.let { m ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete ${m.name}?") },
            text = { Text("Its reminders will be cancelled. Past history stays in Monitoring.") },
            confirmButton = { TextButton({ vm.delete(m); toDelete = null }) { Text("Delete", color = Red) } },
            dismissButton = { TextButton({ toDelete = null }) { Text("Cancel") } }
        )
    }
}

// ---------- 4. Monitoring ----------

@Composable
fun MonitoringScreen(vm: MainVM) {
    val logs by vm.logs.collectAsState()
    val h24 = vm.prefs.use24h
    var month by remember { mutableStateOf(YearMonth.now()) }
    var selected by remember { mutableLongStateOf(LocalDate.now().toEpochDay()) }
    var weekly by remember { mutableStateOf(false) }

    val from = if (weekly) selected - 6 else selected
    val range = remember(logs, from, selected) { logs.filter { it.day in from..selected } }
    val taken = range.count { it.status == "TAKEN" }
    val missed = range.count { it.status == "MISSED" }
    val skipped = range.count { it.status == "SKIPPED" }
    val total = taken + missed + skipped
    val adherence = if (total == 0) null else taken * 100 / total
    val byDay = remember(logs) { logs.groupBy { it.day } }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Monitoring", style = MaterialTheme.typography.headlineMedium) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(!weekly, { weekly = false }, label = { Text("Daily", fontSize = 17.sp) })
                FilterChip(weekly, { weekly = true }, label = { Text("Weekly (7 days)", fontSize = 17.sp) })
            }
            Text(if (weekly) "${dayText(from)} – ${dayText(selected)}" else dayText(selected, "EEEE, MMM d"),
                style = MaterialTheme.typography.bodyLarge)
        }
        item {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Adherence", style = MaterialTheme.typography.bodyMedium)
                    Text(if (adherence == null) "No records yet" else "$adherence%", style = MaterialTheme.typography.headlineMedium)
                    LinearProgressIndicator(progress = { (adherence ?: 0) / 100f }, color = Green,
                        modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)))
                    Text("Taken ÷ (Taken + Missed + Skipped)", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatBox("Taken", taken, Green, Modifier.weight(1f))
                StatBox("Missed", missed, Red, Modifier.weight(1f))
                StatBox("Skipped", skipped, Grey, Modifier.weight(1f))
            }
        }
        item {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton({ month = month.minusMonths(1) }) { Text("‹", fontSize = 32.sp) }
                        Text(month.format(DateTimeFormatter.ofPattern("MMMM yyyy")), Modifier.weight(1f),
                            textAlign = TextAlign.Center, style = MaterialTheme.typography.titleMedium)
                        TextButton({ month = month.plusMonths(1) }) { Text("›", fontSize = 32.sp) }
                    }
                    Row(Modifier.fillMaxWidth()) {
                        listOf("S", "M", "T", "W", "T", "F", "S").forEach {
                            Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
                        }
                    }
                    val offset = month.atDay(1).dayOfWeek.value % 7
                    val days = month.lengthOfMonth()
                    val todayEpoch = LocalDate.now().toEpochDay()
                    for (week in 0 until 6) {
                        if (week * 7 - offset + 1 > days) break
                        Row(Modifier.fillMaxWidth()) {
                            for (dow in 0 until 7) {
                                val n = week * 7 + dow - offset + 1
                                if (n < 1 || n > days) {
                                    Spacer(Modifier.weight(1f).height(50.dp))
                                } else {
                                    val ep = month.atDay(n).toEpochDay()
                                    val st = byDay[ep]
                                    val dot = when {
                                        st == null -> Color.Transparent
                                        st.any { it.status == "MISSED" } -> Red
                                        st.all { it.status == "TAKEN" } -> Green
                                        else -> Orange
                                    }
                                    Box(Modifier.weight(1f).height(50.dp).padding(2.dp).clip(RoundedCornerShape(12.dp))
                                        .background(if (ep == selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                                        .clickable { selected = ep }, contentAlignment = Alignment.Center) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text("$n", fontWeight = if (ep == todayEpoch) FontWeight.ExtraBold else FontWeight.Normal,
                                                color = if (ep == todayEpoch) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                                            Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
                                        }
                                    }
                                }
                            }
                        }
                    }
                    Text("● green: all taken   ● orange: some skipped   ● red: missed", style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
        item { Text("History", style = MaterialTheme.typography.titleLarge) }
        if (range.isEmpty()) item { Text("Nothing recorded for this period.", style = MaterialTheme.typography.bodyLarge) }
        items(range.sortedWith(compareByDescending<DoseLog> { it.day }.thenByDescending { it.minutes }), key = { it.id }) { l ->
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(l.medicineName, style = MaterialTheme.typography.titleMedium)
                        Text("${if (weekly) dayText(l.day) + " • " else ""}${fmtTime(l.minutes, h24)} • ${l.dosage}",
                            style = MaterialTheme.typography.bodyMedium)
                    }
                    StatusChip(l.status)
                }
            }
        }
    }
}

@Composable
private fun StatBox(label: String, n: Int, color: Color, modifier: Modifier) {
    Card(modifier, shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$n", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = color)
            Text(label, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

// ---------- 5. Settings ----------

@Composable
fun SettingsScreen(vm: MainVM) {
    val ctx = LocalContext.current
    val p = vm.prefs
    val tick = rememberResumeTick()
    val notifOn = remember(tick) { Perms.notificationsOn(ctx) }
    val exactOn = remember(tick) { Perms.exactOk(ctx) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data ?: return@rememberLauncherForActivityResult
        val uri = IntentCompat.getParcelableExtra(data, RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
        p.soundUri = uri?.toString() ?: ""
        p.save()
    }
    val soundName = remember(p.soundUri) {
        try {
            val u = if (p.soundUri.isEmpty()) RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) else Uri.parse(p.soundUri)
            RingtoneManager.getRingtone(ctx, u)?.getTitle(ctx) ?: "Default alarm"
        } catch (e: Exception) { "Default alarm" }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium)
        Text("MediCare", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleMedium)

        SectionCard("Alarm") {
            SwitchRow("Alarm sound", p.sound) { p.sound = it; p.save() }
            SwitchRow("Vibration", p.vibrate) { p.vibrate = it; p.save() }
            Text("Notification sound: $soundName", style = MaterialTheme.typography.bodyLarge)
            OutlinedButton({
                picker.launch(Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                    .putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM or RingtoneManager.TYPE_NOTIFICATION or RingtoneManager.TYPE_RINGTONE)
                    .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                    .putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI,
                        if (p.soundUri.isEmpty()) null else Uri.parse(p.soundUri)))
            }, Modifier.heightIn(min = 52.dp)) { Text("Choose sound") }
            Text("Snooze duration", style = MaterialTheme.typography.bodyLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScrollCompat()) {
                listOf(5, 10, 15, 20, 30).forEach { m ->
                    FilterChip(p.snoozeMin == m, { p.snoozeMin = m; p.save() }, label = { Text("$m min", fontSize = 16.sp) })
                }
            }
            OutlinedButton({
                AlarmScheduler.scheduleTest(ctx)
                Toast.makeText(ctx, "Test alarm in 10 seconds. You can close the app now.", Toast.LENGTH_LONG).show()
            }, Modifier.heightIn(min = 52.dp)) { Text("Test alarm (10 seconds)") }
        }

        SectionCard("Display") {
            Text("Time format", style = MaterialTheme.typography.bodyLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(!p.use24h, { p.use24h = false; p.save() }, label = { Text("12-hour", fontSize = 16.sp) })
                FilterChip(p.use24h, { p.use24h = true; p.save() }, label = { Text("24-hour", fontSize = 16.sp) })
            }
            Text("Theme", style = MaterialTheme.typography.bodyLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("System", "Light", "Dark").forEachIndexed { i, label ->
                    FilterChip(p.theme == i, { p.theme = i; p.save() }, label = { Text(label, fontSize = 16.sp) })
                }
            }
        }

        SectionCard("Permissions") {
            Text(if (notifOn) "✓ Notifications are allowed" else "✗ Notifications are blocked",
                color = if (notifOn) Green else Red, fontWeight = FontWeight.Bold)
            OutlinedButton({
                ctx.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }, Modifier.heightIn(min = 52.dp)) { Text("Manage notification permission") }

            Text(if (exactOn) "✓ Exact alarms are allowed" else "✗ Exact alarms are off (backup mode in use)",
                color = if (exactOn) Green else Red, fontWeight = FontWeight.Bold)
            if (!exactOn && Build.VERSION.SDK_INT >= 31) OutlinedButton({
                ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }, Modifier.heightIn(min = 52.dp)) { Text("Allow exact alarms") }

            Text("For the most reliable alarms, set MediCare to “Unrestricted” / “Don't optimize” battery use. " +
                "On Xiaomi, Oppo, Vivo, Huawei and Samsung phones, also enable Autostart / “Allow background activity”.",
                style = MaterialTheme.typography.bodyMedium)
            OutlinedButton({
                ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }, Modifier.heightIn(min = 52.dp)) { Text("Open battery settings") }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            content()
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        Switch(checked, onChange)
    }
}
