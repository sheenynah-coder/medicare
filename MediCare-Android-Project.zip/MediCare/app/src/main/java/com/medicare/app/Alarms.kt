package com.medicare.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

object X {
    const val MED = "medId"; const val DAY = "day"; const val MIN = "min"
    const val NAME = "name"; const val DOSAGE = "dosage"
    const val SNOOZE = "snooze"; const val TEST = "test"; const val OPEN = "openFromNotif"
    const val ACT_ALARM = "com.medicare.app.ALARM"
    const val ACT_TAKEN = "com.medicare.app.TAKEN"
    const val ACT_SNOOZE = "com.medicare.app.SNOOZE"
}

/** Status checks used by the in-app diagnostics screen and the Home warning banner. */
object Perms {
    fun notificationsOn(ctx: Context) = NotificationManagerCompat.from(ctx).areNotificationsEnabled()
    fun exactOk(ctx: Context) =
        Build.VERSION.SDK_INT < 31 || ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
    fun batteryExempt(ctx: Context) =
        ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)
    fun channelOk(ctx: Context): Boolean {
        val ch = ctx.getSystemService(NotificationManager::class.java).getNotificationChannel(Notifier.CH)
        return ch != null && ch.importance != NotificationManager.IMPORTANCE_NONE
    }
    fun fullScreenOk(ctx: Context) =
        Build.VERSION.SDK_INT < 34 || ctx.getSystemService(NotificationManager::class.java).canUseFullScreenIntent()
    fun setupComplete(ctx: Context) = notificationsOn(ctx) && channelOk(ctx) && batteryExempt(ctx)
}

/**
 * Schedules ONE pending alarm per (medicine, time-of-day) using AlarmManager.setAlarmClock, which Android
 * treats as a user-visible alarm: exact to the minute, allowed in Doze, and it needs no special permission.
 * Request code = medicineId*2000 + minuteOfDay with FLAG_UPDATE_CURRENT, so re-scheduling REPLACES the existing
 * alarm and can never create duplicates. When an alarm fires, the next day's alarm is scheduled.
 */
object AlarmScheduler {
    private const val SNOOZE_BASE = 1_000_000_000
    private const val TEST_CODE = 2_000_000_000

    fun code(medId: Long, min: Int): Int = (medId * 2000 + min).toInt()

    private fun am(ctx: Context) = ctx.getSystemService(AlarmManager::class.java)
    private fun baseIntent(ctx: Context) = Intent(ctx, AlarmReceiver::class.java).setAction(X.ACT_ALARM)

    private fun pi(ctx: Context, code: Int, medId: Long, day: Long, min: Int, name: String, dosage: String,
                   snooze: Boolean = false, test: Boolean = false): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, code,
            baseIntent(ctx).putExtra(X.MED, medId).putExtra(X.DAY, day).putExtra(X.MIN, min)
                .putExtra(X.NAME, name).putExtra(X.DOSAGE, dosage)
                .putExtra(X.SNOOZE, snooze).putExtra(X.TEST, test),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    fun isScheduled(ctx: Context, code: Int): Boolean =
        PendingIntent.getBroadcast(ctx, code, baseIntent(ctx),
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE) != null

    private fun cancel(ctx: Context, code: Int) {
        PendingIntent.getBroadcast(ctx, code, baseIntent(ctx),
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)?.let {
            am(ctx).cancel(it); it.cancel()
        }
    }

    private fun setAlarm(ctx: Context, at: Long, pi: PendingIntent) {
        val manager = am(ctx)
        try {
            val show = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            manager.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi)
        } catch (e: Exception) {
            Log.w("MediCare", "setAlarmClock failed, trying exact/inexact fallback", e)
            try {
                if (Perms.exactOk(ctx)) manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                else manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } catch (e2: Exception) {
                Log.e("MediCare", "All alarm scheduling methods failed", e2)
            }
        }
    }

    fun scheduleNext(ctx: Context, m: Medicine, min: Int, after: Long = System.currentTimeMillis()) {
        val start = maxOf(LocalDate.now().toEpochDay(), m.startDay)
        for (d in 0..2) {
            val day = start + d
            if (m.endDay >= 0 && day > m.endDay) break
            val due = Repo.dueMillis(day, min)
            if (due > after) {
                setAlarm(ctx, due, pi(ctx, code(m.id, min), m.id, day, min, m.name, m.dosage))
                return
            }
        }
        cancel(ctx, code(m.id, min))
    }

    suspend fun rescheduleAll(ctx: Context) {
        for (m in AppDb.get(ctx).dao().allMedicines())
            for (min in m.minuteList()) scheduleNext(ctx, m, min)
    }

    /** How many (medicine, time) alarms are expected vs actually registered with Android. */
    suspend fun registeredCount(ctx: Context): Pair<Int, Int> {
        var expected = 0; var registered = 0
        val today = LocalDate.now().toEpochDay()
        for (m in AppDb.get(ctx).dao().allMedicines()) {
            if (m.endDay in 0 until today) continue
            for (min in m.minuteList()) { expected++; if (isScheduled(ctx, code(m.id, min))) registered++ }
        }
        return registered to expected
    }

    fun snooze(ctx: Context, m: Medicine, day: Long, min: Int, minutes: Int) {
        setAlarm(ctx, System.currentTimeMillis() + minutes * 60_000L,
            pi(ctx, SNOOZE_BASE + code(m.id, min), m.id, day, min, m.name, m.dosage, snooze = true))
    }

    suspend fun snoozeDose(ctx: Context, medId: Long, day: Long, min: Int) {
        val m = AppDb.get(ctx).dao().medicine(medId) ?: return
        snooze(ctx, m, day, min, Prefs(ctx).snoozeMin)
        ctx.getSystemService(NotificationManager::class.java).cancel(code(medId, min))
        ctx.stopService(Intent(ctx, AlarmService::class.java))
    }

    fun cancelSnooze(ctx: Context, medId: Long, min: Int) = cancel(ctx, SNOOZE_BASE + code(medId, min))

    fun cancelAll(ctx: Context, m: Medicine) {
        for (min in m.minuteList()) { cancel(ctx, code(m.id, min)); cancel(ctx, SNOOZE_BASE + code(m.id, min)) }
    }

    /** Fires a test alarm through the real AlarmManager path after [seconds]. */
    fun scheduleTest(ctx: Context, seconds: Int = 10) {
        setAlarm(ctx, System.currentTimeMillis() + seconds * 1000L,
            pi(ctx, TEST_CODE, -1, 0, 0, "Test medicine", "1 tablet (test)", test = true))
    }
}

object Notifier {
    const val CH = "medicare_alarm_v2"
    const val CH_FALLBACK = "medicare_alarm_backup_v2"

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.deleteNotificationChannel("medicare_alarm")
        nm.deleteNotificationChannel("medicare_alarm_fallback")
        // Main channel (HIGH importance) is silent: AlarmService plays the chosen sound/vibration itself, looping.
        nm.createNotificationChannel(NotificationChannel(CH, "Medicine alarms",
            NotificationManager.IMPORTANCE_HIGH).apply {
            description = "MediCare alarms for scheduled medicines"
            setSound(null, null); enableVibration(false)
        })
        // Backup channel with its own alarm sound, used only if Android blocks the alarm service.
        nm.createNotificationChannel(NotificationChannel(CH_FALLBACK, "Medicine alarms (backup)",
            NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Used only if the main alarm cannot start"
            setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
            enableVibration(true); vibrationPattern = longArrayOf(0, 600, 400, 600, 400, 600)
        })
    }

    private fun action(ctx: Context, act: String, medId: Long, day: Long, min: Int, req: Int) =
        PendingIntent.getBroadcast(ctx, req,
            Intent(ctx, ActionReceiver::class.java).setAction(act)
                .putExtra(X.MED, medId).putExtra(X.DAY, day).putExtra(X.MIN, min),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun build(ctx: Context, medId: Long, day: Long, min: Int, name: String, dosage: String,
              ongoing: Boolean, channel: String = CH): Notification {
        val prefs = Prefs(ctx)
        val nid = AlarmScheduler.code(medId, min)
        val open = PendingIntent.getActivity(ctx, nid * 4 + 3,
            Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra(X.OPEN, true).putExtra(X.MED, medId).putExtra(X.DAY, day).putExtra(X.MIN, min),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val timeText = if (medId > 0) fmtTime(min, prefs.use24h) else "now"
        val b = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("MediCare: time to take $name")
            .setContentText("Dosage: $dosage  •  $timeText")
            .setStyle(NotificationCompat.BigTextStyle().bigText("Medicine: $name\nDosage: $dosage\nScheduled: $timeText"))
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(ongoing)
            .setAutoCancel(false)
            .setContentIntent(open)
            .addAction(0, "Mark as Taken", action(ctx, X.ACT_TAKEN, medId, day, min, nid * 4 + 1))
            .addAction(0, "Snooze ${prefs.snoozeMin} min", action(ctx, X.ACT_SNOOZE, medId, day, min, nid * 4 + 2))
        if (prefs.lockScreen) {
            b.setVisibility(NotificationCompat.VISIBILITY_PUBLIC).setFullScreenIntent(open, true)
        } else {
            // Privacy mode: lock screen only shows a generic message.
            b.setVisibility(NotificationCompat.VISIBILITY_PRIVATE).setPublicVersion(
                NotificationCompat.Builder(ctx, channel).setSmallIcon(R.drawable.ic_notification)
                    .setContentTitle("MediCare").setContentText("It's time for a medicine reminder").build())
        }
        return b.build()
    }

    /** Diagnostic: shows a normal alarm-style notification immediately (backup channel, has its own sound). */
    fun postTest(ctx: Context) {
        ctx.getSystemService(NotificationManager::class.java).notify(
            AlarmScheduler.code(-1, 1),
            build(ctx, -1, 0, 1, "Test medicine", "1 tablet (test)", ongoing = false, channel = CH_FALLBACK))
    }
}

private fun ringNow(ctx: Context, medId: Long, day: Long, min: Int, name: String, dosage: String, test: Boolean) {
    try {
        ContextCompat.startForegroundService(ctx, Intent(ctx, AlarmService::class.java)
            .putExtra(X.MED, medId).putExtra(X.DAY, day).putExtra(X.MIN, min)
            .putExtra(X.NAME, name).putExtra(X.DOSAGE, dosage).putExtra(X.TEST, test))
    } catch (e: Exception) {
        Log.w("MediCare", "Foreground service blocked, posting backup notification", e)
        ctx.getSystemService(NotificationManager::class.java).notify(
            AlarmScheduler.code(medId, min),
            Notifier.build(ctx, medId, day, min, name, dosage, ongoing = false, channel = Notifier.CH_FALLBACK))
    }
}

private fun wakeLock(ctx: Context, tag: String, ms: Long): PowerManager.WakeLock =
    ctx.getSystemService(PowerManager::class.java)
        .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MediCare:$tag").apply { setReferenceCounted(false); acquire(ms) }

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        // Keep the CPU awake while we hand over to the alarm service and do bookkeeping.
        val wl = wakeLock(ctx, "alarm", 30_000)
        val pending = goAsync()
        val medId = intent.getLongExtra(X.MED, 0)
        val day = intent.getLongExtra(X.DAY, 0)
        val min = intent.getIntExtra(X.MIN, 0)
        val test = intent.getBooleanExtra(X.TEST, false)
        val snooze = intent.getBooleanExtra(X.SNOOZE, false)

        // 1) Ring IMMEDIATELY, without waiting for the database (the service double-checks the dose).
        ringNow(ctx, medId, day, min, intent.getStringExtra(X.NAME) ?: "your medicine",
            intent.getStringExtra(X.DOSAGE) ?: "", test)

        // 2) Bookkeeping: schedule tomorrow's alarm, record overdue doses.
        CoroutineScope(Dispatchers.IO).launch {
            try {
                if (!test && !snooze) {
                    AppDb.get(ctx).dao().medicine(medId)?.let {
                        AlarmScheduler.scheduleNext(ctx, it, min, System.currentTimeMillis() + 60_000)
                    }
                }
                Repo.markOverdue(ctx)
            } catch (e: Exception) {
                Log.e("MediCare", "Alarm bookkeeping failed", e)
            } finally {
                if (wl.isHeld) wl.release()
                pending.finish()
            }
        }
    }
}

/** Plays the looping alarm sound + vibration and shows the ongoing notification. Auto-stops after 2 minutes. */
class AlarmService : Service() {
    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private var wl: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) { stopSelf(); return START_NOT_STICKY }
        val medId = intent.getLongExtra(X.MED, 0)
        val day = intent.getLongExtra(X.DAY, 0)
        val min = intent.getIntExtra(X.MIN, 0)
        val name = intent.getStringExtra(X.NAME) ?: "your medicine"
        val dosage = intent.getStringExtra(X.DOSAGE) ?: ""
        val test = intent.getBooleanExtra(X.TEST, false)
        val nid = AlarmScheduler.code(medId, min)

        ServiceCompat.startForeground(this, nid,
            Notifier.build(this, medId, day, min, name, dosage, ongoing = true),
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0)

        if (wl?.isHeld != true) wl = wakeLock(this, "ring", 150_000)
        stopFeedback()
        handler.removeCallbacksAndMessages(null)

        scope.launch {
            val skip = withContext(Dispatchers.IO) { shouldSkip(medId, day, min, test) }
            if (skip) {
                stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return@launch
            }
            startFeedback()
            handler.postDelayed({
                // Time-out: silence, but keep a dismissable reminder. Nothing is recorded as Taken.
                stopFeedback()
                stopForeground(STOP_FOREGROUND_DETACH)
                getSystemService(NotificationManager::class.java).notify(nid,
                    Notifier.build(this@AlarmService, medId, day, min, name, dosage, ongoing = false))
                stopSelf()
            }, 2 * 60_000L)
        }
        return START_NOT_STICKY
    }

    /** True if the dose was already confirmed (or the medicine was deleted), so we must not ring. */
    private suspend fun shouldSkip(medId: Long, day: Long, min: Int, test: Boolean): Boolean {
        if (test) return false
        val dao = AppDb.get(this).dao()
        if (dao.medicine(medId) == null) return true
        val log = dao.log(medId, day, min)
        return log != null && log.status != "MISSED"
    }

    private fun startFeedback() {
        val prefs = Prefs(this)
        if (prefs.sound) {
            try {
                val uri = if (prefs.soundUri.isNotEmpty()) Uri.parse(prefs.soundUri)
                else RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                player = MediaPlayer().apply {
                    setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    setWakeMode(this@AlarmService, PowerManager.PARTIAL_WAKE_LOCK)
                    setDataSource(this@AlarmService, uri)
                    isLooping = true
                    prepare(); start()
                }
            } catch (e: Exception) { Log.e("MediCare", "Could not play alarm sound", e) }
        }
        if (prefs.vibrate) {
            try {
                @Suppress("DEPRECATION")
                vibrator = if (Build.VERSION.SDK_INT >= 31)
                    getSystemService(VibratorManager::class.java).defaultVibrator
                else getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 700, 500), 0))
            } catch (e: Exception) { Log.e("MediCare", "Could not vibrate", e) }
        }
    }

    private fun stopFeedback() {
        try { player?.stop() } catch (_: Exception) {}
        player?.release(); player = null
        vibrator?.cancel(); vibrator = null
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        scope.cancel()
        stopFeedback()
        if (wl?.isHeld == true) wl?.release()
        super.onDestroy()
    }
}

/** Handles the notification buttons: Mark as Taken / Snooze. Only a button tap changes a dose's status. */
class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val wl = wakeLock(ctx, "action", 20_000)
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val medId = intent.getLongExtra(X.MED, 0)
                val day = intent.getLongExtra(X.DAY, 0)
                val min = intent.getIntExtra(X.MIN, 0)
                ctx.getSystemService(NotificationManager::class.java).cancel(AlarmScheduler.code(medId, min))
                ctx.stopService(Intent(ctx, AlarmService::class.java))
                if (medId > 0) when (intent.action) {
                    X.ACT_TAKEN -> Repo.record(ctx, medId, day, min, "TAKEN")
                    X.ACT_SNOOZE -> AlarmScheduler.snoozeDose(ctx, medId, day, min)
                }
            } catch (e: Exception) {
                Log.e("MediCare", "Action failed", e)
            } finally {
                if (wl.isHeld) wl.release()
                pending.finish()
            }
        }
    }
}

/** Restores alarms after reboot, app update, clock or timezone change, or exact-alarm permission change. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val wl = wakeLock(ctx, "boot", 30_000)
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                Repo.markOverdue(ctx)
                AlarmScheduler.rescheduleAll(ctx)
            } catch (e: Exception) {
                Log.e("MediCare", "Reschedule failed", e)
            } finally {
                if (wl.isHeld) wl.release()
                pending.finish()
            }
        }
    }
}
