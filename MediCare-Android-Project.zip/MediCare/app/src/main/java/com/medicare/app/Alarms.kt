package com.medicare.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate

object X {
    const val MED = "medId"; const val DAY = "day"; const val MIN = "min"
    const val NAME = "name"; const val DOSAGE = "dosage"
    const val SNOOZE = "snooze"; const val TEST = "test"
    const val ACT_ALARM = "com.medicare.app.ALARM"
    const val ACT_TAKEN = "com.medicare.app.TAKEN"
    const val ACT_SNOOZE = "com.medicare.app.SNOOZE"
}

object Perms {
    fun notificationsOn(ctx: Context) = NotificationManagerCompat.from(ctx).areNotificationsEnabled()
    fun exactOk(ctx: Context) =
        Build.VERSION.SDK_INT < 31 || ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
}

/**
 * Schedules ONE pending alarm per (medicine, time-of-day). The PendingIntent request code is derived
 * from the medicine id + minute, with FLAG_UPDATE_CURRENT, so re-scheduling replaces the existing alarm
 * and can never create duplicates. When an alarm fires, the next day's alarm is scheduled.
 */
object AlarmScheduler {
    private const val SNOOZE_BASE = 1_000_000_000
    private const val TEST_CODE = 2_000_000_000

    fun code(medId: Long, min: Int): Int = (medId * 2000 + min).toInt()

    private fun am(ctx: Context) = ctx.getSystemService(AlarmManager::class.java)
    private fun baseIntent(ctx: Context) = Intent(ctx, AlarmReceiver::class.java).setAction(X.ACT_ALARM)

    private fun pi(ctx: Context, code: Int, medId: Long, day: Long, min: Int,
                   snooze: Boolean = false, test: Boolean = false): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, code,
            baseIntent(ctx).putExtra(X.MED, medId).putExtra(X.DAY, day).putExtra(X.MIN, min)
                .putExtra(X.SNOOZE, snooze).putExtra(X.TEST, test),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun cancel(ctx: Context, code: Int) {
        PendingIntent.getBroadcast(ctx, code, baseIntent(ctx),
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)?.let {
            am(ctx).cancel(it); it.cancel()
        }
    }

    private fun setAlarm(ctx: Context, at: Long, pi: PendingIntent) {
        val manager = am(ctx)
        try {
            if (Perms.exactOk(ctx)) {
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                // Fallback when "Alarms & reminders" permission is off: setAlarmClock is exact and
                // needs no special permission (shows an alarm icon in the status bar).
                val show = PendingIntent.getActivity(
                    ctx, 0, Intent(ctx, MainActivity::class.java),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                manager.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi)
            }
        } catch (e: SecurityException) {
            Log.w("MediCare", "Exact alarm denied, using inexact fallback", e)
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun scheduleNext(ctx: Context, m: Medicine, min: Int, after: Long = System.currentTimeMillis()) {
        val start = maxOf(LocalDate.now().toEpochDay(), m.startDay)
        for (d in 0..2) {
            val day = start + d
            if (m.endDay >= 0 && day > m.endDay) break
            val due = Repo.dueMillis(day, min)
            if (due > after) {
                setAlarm(ctx, due, pi(ctx, code(m.id, min), m.id, day, min))
                return
            }
        }
        cancel(ctx, code(m.id, min))
    }

    suspend fun rescheduleAll(ctx: Context) {
        for (m in AppDb.get(ctx).dao().allMedicines())
            for (min in m.minuteList()) scheduleNext(ctx, m, min)
    }

    fun snooze(ctx: Context, medId: Long, day: Long, min: Int, minutes: Int) {
        setAlarm(ctx, System.currentTimeMillis() + minutes * 60_000L,
            pi(ctx, SNOOZE_BASE + code(medId, min), medId, day, min, snooze = true))
    }

    fun cancelSnooze(ctx: Context, medId: Long, min: Int) = cancel(ctx, SNOOZE_BASE + code(medId, min))

    fun cancelAll(ctx: Context, m: Medicine) {
        for (min in m.minuteList()) { cancel(ctx, code(m.id, min)); cancel(ctx, SNOOZE_BASE + code(m.id, min)) }
    }

    /** Fires a test alarm through the real AlarmManager path in 10 seconds. */
    fun scheduleTest(ctx: Context) {
        setAlarm(ctx, System.currentTimeMillis() + 10_000L, pi(ctx, TEST_CODE, -1, 0, 0, test = true))
    }
}

object Notifier {
    const val CH = "medicare_alarm"
    const val CH_FALLBACK = "medicare_alarm_fallback"

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        // Main channel is silent: AlarmService plays the user's chosen sound/vibration itself (looping).
        nm.createNotificationChannel(NotificationChannel(CH, "MediCare medicine alarms",
            NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Alarms for scheduled medicines"
            setSound(null, null); enableVibration(false)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        })
        // Used only if Android refuses to start the alarm service (rare, background restrictions).
        nm.createNotificationChannel(NotificationChannel(CH_FALLBACK, "MediCare alarms (backup)",
            NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
            enableVibration(true); vibrationPattern = longArrayOf(0, 600, 400, 600, 400, 600)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        })
    }

    private fun action(ctx: Context, act: String, medId: Long, day: Long, min: Int, req: Int) =
        PendingIntent.getBroadcast(ctx, req,
            Intent(ctx, ActionReceiver::class.java).setAction(act)
                .putExtra(X.MED, medId).putExtra(X.DAY, day).putExtra(X.MIN, min),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun build(ctx: Context, medId: Long, day: Long, min: Int, name: String, dosage: String,
              ongoing: Boolean, channel: String = CH): Notification {
        val prefs = Prefs(ctx)
        val nid = AlarmScheduler.code(medId, min)
        val open = PendingIntent.getActivity(ctx, nid * 4 + 3,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val timeText = if (medId > 0) fmtTime(min, prefs.use24h) else "now"
        return NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("MediCare: time to take $name")
            .setContentText("Dosage: $dosage  •  $timeText")
            .setStyle(NotificationCompat.BigTextStyle().bigText("Medicine: $name\nDosage: $dosage\nScheduled: $timeText"))
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(ongoing)
            .setAutoCancel(false)
            .setContentIntent(open)
            .setFullScreenIntent(open, true)
            .addAction(0, "Mark as Taken", action(ctx, X.ACT_TAKEN, medId, day, min, nid * 4 + 1))
            .addAction(0, "Snooze ${prefs.snoozeMin} min", action(ctx, X.ACT_SNOOZE, medId, day, min, nid * 4 + 2))
            .build()
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val medId = intent.getLongExtra(X.MED, 0)
                val day = intent.getLongExtra(X.DAY, 0)
                val min = intent.getIntExtra(X.MIN, 0)
                if (intent.getBooleanExtra(X.TEST, false)) {
                    ring(ctx, -1, 0, 0, "Test medicine", "This is a test alarm"); return@launch
                }
                val dao = AppDb.get(ctx).dao()
                val m = dao.medicine(medId) ?: return@launch
                if (!intent.getBooleanExtra(X.SNOOZE, false)) {
                    // Chain: schedule tomorrow's occurrence right away (idempotent per medicine+time).
                    AlarmScheduler.scheduleNext(ctx, m, min, System.currentTimeMillis() + 60_000)
                }
                Repo.markOverdue(ctx)
                val existing = dao.log(medId, day, min)
                if (existing != null && existing.status != "MISSED") return@launch   // already handled
                ring(ctx, medId, day, min, m.name, m.dosage)
            } catch (e: Exception) {
                Log.e("MediCare", "Alarm handling failed", e)
            } finally {
                pending.finish()
            }
        }
    }

    private fun ring(ctx: Context, medId: Long, day: Long, min: Int, name: String, dosage: String) {
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, AlarmService::class.java)
                .putExtra(X.MED, medId).putExtra(X.DAY, day).putExtra(X.MIN, min)
                .putExtra(X.NAME, name).putExtra(X.DOSAGE, dosage))
        } catch (e: Exception) {
            Log.w("MediCare", "Foreground service blocked, posting backup notification", e)
            ctx.getSystemService(NotificationManager::class.java).notify(
                AlarmScheduler.code(medId, min),
                Notifier.build(ctx, medId, day, min, name, dosage, ongoing = false, channel = Notifier.CH_FALLBACK))
        }
    }
}

/** Plays the looping alarm sound + vibration and shows the ongoing notification. Auto-stops after 2 minutes. */
class AlarmService : Service() {
    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) { stopSelf(); return START_NOT_STICKY }
        val medId = intent.getLongExtra(X.MED, 0)
        val day = intent.getLongExtra(X.DAY, 0)
        val min = intent.getIntExtra(X.MIN, 0)
        val name = intent.getStringExtra(X.NAME) ?: "your medicine"
        val dosage = intent.getStringExtra(X.DOSAGE) ?: ""
        val nid = AlarmScheduler.code(medId, min)

        ServiceCompat.startForeground(this, nid,
            Notifier.build(this, medId, day, min, name, dosage, ongoing = true),
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0)

        stopFeedback()
        startFeedback()
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({
            // Time-out: silence, but keep a (dismissable) reminder. Nothing is recorded as Taken.
            stopFeedback()
            stopForeground(STOP_FOREGROUND_DETACH)
            getSystemService(NotificationManager::class.java).notify(nid,
                Notifier.build(this, medId, day, min, name, dosage, ongoing = false))
            stopSelf()
        }, 2 * 60_000L)
        return START_NOT_STICKY
    }

    private fun startFeedback() {
        val prefs = Prefs(this)
        if (prefs.sound) {
            try {
                val uri = if (prefs.soundUri.isNotEmpty()) Uri.parse(prefs.soundUri)
                else RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                player = MediaPlayer().apply {
                    setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    setDataSource(this@AlarmService, uri)
                    isLooping = true
                    prepare(); start()
                }
            } catch (e: Exception) { Log.e("MediCare", "Could not play alarm sound", e) }
        }
        if (prefs.vibrate) {
            try {
                @Suppress("DEPRECATION")
                vibrator = if (Build.VERSION.SDK_INT >= 31)
                    getSystemService(VibratorManager::class.java).defaultVibrator
                else getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 700, 500), 0))
            } catch (e: Exception) { Log.e("MediCare", "Could not vibrate", e) }
        }
    }

    private fun stopFeedback() {
        try { player?.stop() } catch (_: Exception) {}
        player?.release(); player = null
        vibrator?.cancel(); vibrator = null
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        stopFeedback()
        super.onDestroy()
    }
}

/** Handles the notification buttons: Mark as Taken / Snooze. */
class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val medId = intent.getLongExtra(X.MED, 0)
                val day = intent.getLongExtra(X.DAY, 0)
                val min = intent.getIntExtra(X.MIN, 0)
                ctx.getSystemService(NotificationManager::class.java).cancel(AlarmScheduler.code(medId, min))
                ctx.stopService(Intent(ctx, AlarmService::class.java))
                if (medId > 0) when (intent.action) {
                    X.ACT_TAKEN -> Repo.record(ctx, medId, day, min, "TAKEN")
                    X.ACT_SNOOZE -> AlarmScheduler.snooze(ctx, medId, day, min, Prefs(ctx).snoozeMin)
                }
            } catch (e: Exception) {
                Log.e("MediCare", "Action failed", e)
            } finally {
                pending.finish()
            }
        }
    }
}

/** Restores alarms after reboot, app update, clock or timezone change, or exact-alarm permission change. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                Repo.markOverdue(ctx)
                AlarmScheduler.rescheduleAll(ctx)
            } catch (e: Exception) {
                Log.e("MediCare", "Reschedule failed", e)
            } finally {
                pending.finish()
            }
        }
    }
}
