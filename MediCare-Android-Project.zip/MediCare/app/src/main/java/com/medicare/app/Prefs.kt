package com.medicare.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** User preferences (stored locally). Set a property, then call save(). */
class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("medicare_prefs", Context.MODE_PRIVATE)

    var sound by mutableStateOf(sp.getBoolean("sound", true))
    var vibrate by mutableStateOf(sp.getBoolean("vibrate", true))
    var soundUri by mutableStateOf(sp.getString("soundUri", "") ?: "")   // "" = default alarm sound
    var snoozeMin by mutableStateOf(sp.getInt("snooze", 10))
    var use24h by mutableStateOf(sp.getBoolean("h24", false))
    var theme by mutableStateOf(sp.getInt("theme", 0))                  // 0 system, 1 light, 2 dark

    fun save() {
        sp.edit().putBoolean("sound", sound).putBoolean("vibrate", vibrate).putString("soundUri", soundUri)
            .putInt("snooze", snoozeMin).putBoolean("h24", use24h).putInt("theme", theme).apply()
    }
}
