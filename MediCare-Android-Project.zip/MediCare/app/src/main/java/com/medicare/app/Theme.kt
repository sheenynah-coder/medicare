package com.medicare.app

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val LightColors = lightColorScheme(
    primary = Color(0xFF3D8BE0), onPrimary = Color.White,
    primaryContainer = Color(0xFFDCEBFB), onPrimaryContainer = Color(0xFF0D3558),
    secondary = Color(0xFF3FB68B), onSecondary = Color.White,
    secondaryContainer = Color(0xFFDDF5EB), onSecondaryContainer = Color(0xFF0C3B2A),
    background = Color(0xFFF4F8FC), onBackground = Color(0xFF14232F),
    surface = Color.White, onSurface = Color(0xFF14232F),
    surfaceVariant = Color(0xFFE9F1F9), onSurfaceVariant = Color(0xFF52667A),
    errorContainer = Color(0xFFFDE3E1), onErrorContainer = Color(0xFF5C1410)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF8CC4F5), onPrimary = Color(0xFF05293F),
    primaryContainer = Color(0xFF1B4466), onPrimaryContainer = Color(0xFFDCEBFB),
    secondary = Color(0xFF86DDB9), onSecondary = Color(0xFF0B2E1B),
    secondaryContainer = Color(0xFF1F4A38), onSecondaryContainer = Color(0xFFDDF5EB),
    background = Color(0xFF0C1620), onBackground = Color(0xFFE3EEF5),
    surface = Color(0xFF152330), onSurface = Color(0xFFE3EEF5),
    surfaceVariant = Color(0xFF213443), onSurfaceVariant = Color(0xFFB4C8D6),
    errorContainer = Color(0xFF5C1410), onErrorContainer = Color(0xFFFDE3E1)
)

// Large, friendly type for readability.
private val BigType = Typography(
    bodyLarge = TextStyle(fontSize = 20.sp),
    bodyMedium = TextStyle(fontSize = 18.sp),
    bodySmall = TextStyle(fontSize = 16.sp),
    titleLarge = TextStyle(fontSize = 26.sp, fontWeight = FontWeight.Bold),
    titleMedium = TextStyle(fontSize = 21.sp, fontWeight = FontWeight.SemiBold),
    headlineMedium = TextStyle(fontSize = 32.sp, fontWeight = FontWeight.ExtraBold),
    labelLarge = TextStyle(fontSize = 18.sp, fontWeight = FontWeight.SemiBold),
    labelMedium = TextStyle(fontSize = 15.sp)
)

private val SoftShapes = Shapes(
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(22.dp),
    large = RoundedCornerShape(30.dp),
    extraLarge = RoundedCornerShape(36.dp)
)

@Composable
fun MediCareTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = BigType, shapes = SoftShapes, content = content
    )
}
