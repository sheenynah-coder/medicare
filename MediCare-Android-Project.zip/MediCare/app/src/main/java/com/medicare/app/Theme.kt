package com.medicare.app

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val LightColors = lightColorScheme(
    primary = Color(0xFF2B7BB9), onPrimary = Color.White,
    primaryContainer = Color(0xFFD6ECFA), onPrimaryContainer = Color(0xFF0B3550),
    secondary = Color(0xFF3E9B66), onSecondary = Color.White,
    secondaryContainer = Color(0xFFD8F2E2), onSecondaryContainer = Color(0xFF0E3A22),
    background = Color(0xFFF6FBFE), onBackground = Color(0xFF10212B),
    surface = Color.White, onSurface = Color(0xFF10212B),
    surfaceVariant = Color(0xFFE8F3FA), onSurfaceVariant = Color(0xFF38505F),
    errorContainer = Color(0xFFFDE3E1), onErrorContainer = Color(0xFF5C1410)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF8CCBF2), onPrimary = Color(0xFF05293F),
    primaryContainer = Color(0xFF16435F), onPrimaryContainer = Color(0xFFD6ECFA),
    secondary = Color(0xFF8ED8AB), onSecondary = Color(0xFF0B2E1B),
    secondaryContainer = Color(0xFF1F4A33), onSecondaryContainer = Color(0xFFD8F2E2),
    background = Color(0xFF0E1A22), onBackground = Color(0xFFE3EEF5),
    surface = Color(0xFF16252F), onSurface = Color(0xFFE3EEF5),
    surfaceVariant = Color(0xFF223540), onSurfaceVariant = Color(0xFFB9CCD8),
    errorContainer = Color(0xFF5C1410), onErrorContainer = Color(0xFFFDE3E1)
)

// Large type for readability (elderly-friendly).
private val BigType = Typography(
    bodyLarge = TextStyle(fontSize = 20.sp),
    bodyMedium = TextStyle(fontSize = 18.sp),
    bodySmall = TextStyle(fontSize = 16.sp),
    titleLarge = TextStyle(fontSize = 28.sp, fontWeight = FontWeight.Bold),
    titleMedium = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.SemiBold),
    headlineMedium = TextStyle(fontSize = 32.sp, fontWeight = FontWeight.Bold),
    labelLarge = TextStyle(fontSize = 18.sp, fontWeight = FontWeight.SemiBold),
    labelMedium = TextStyle(fontSize = 15.sp)
)

@Composable
fun MediCareTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, typography = BigType, content = content)
}
