package com.medicare.app

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MediCareApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Notifier.createChannels(this)
    }
}

class MainVM(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()
    val prefs = Prefs(app)
    val medicines = dao.medicines().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val logs = dao.allLogs().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Idempotent: records overdue doses and (re)registers every alarm without creating duplicates. */
    fun refresh() {
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>()
            Repo.markOverdue(ctx); AlarmScheduler.rescheduleAll(ctx)
        }
    }
    fun save(m: Medicine) { viewModelScope.launch(Dispatchers.IO) { Repo.save(getApplication(), m) } }
    fun delete(m: Medicine) { viewModelScope.launch(Dispatchers.IO) { Repo.delete(getApplication(), m) } }
    fun record(d: DoseItem, status: String) {
        viewModelScope.launch(Dispatchers.IO) { Repo.record(getApplication(), d.m.id, d.day, d.min, status) }
    }
}

class MainActivity : ComponentActivity() {
    private val vm: MainVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MediCareRoot(vm) }
    }

    override fun onResume() {
        super.onResume()
        vm.refresh()
    }
}
