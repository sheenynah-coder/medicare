package com.medicare.app

import android.app.Application
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MediCareApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Notifier.createChannels(this)
    }
}

/** Identifies one scheduled dose (used when a notification is opened). */
data class DoseRef(val medId: Long, val day: Long, val min: Int)

class MainVM(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()
    val prefs = Prefs(app)
    val medicines = dao.medicines().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val logs = dao.allLogs().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Set when the user taps a medicine notification; the UI then shows that dose directly. */
    var openDose by mutableStateOf<DoseRef?>(null)

    /** Idempotent: records overdue doses and (re)registers every alarm without creating duplicates. */
    fun refresh() {
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>()
            Repo.markOverdue(ctx); AlarmScheduler.rescheduleAll(ctx)
        }
    }
    fun save(m: Medicine) { viewModelScope.launch(Dispatchers.IO) { Repo.save(getApplication(), m) } }
    fun delete(m: Medicine) { viewModelScope.launch(Dispatchers.IO) { Repo.delete(getApplication(), m) } }
    fun record(d: DoseItem, status: String) = recordRef(DoseRef(d.m.id, d.day, d.min), status)
    fun recordRef(r: DoseRef, status: String) {
        viewModelScope.launch(Dispatchers.IO) { Repo.record(getApplication(), r.medId, r.day, r.min, status) }
    }
    fun snooze(r: DoseRef) {
        viewModelScope.launch(Dispatchers.IO) { AlarmScheduler.snoozeDose(getApplication(), r.medId, r.day, r.min) }
    }
}

class MainActivity : ComponentActivity() {
    private val vm: MainVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIntent(intent)
        setContent { MediCareRoot(vm) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    /** Opened from a medicine notification: silence the alarm and show that exact dose. */
    private fun handleIntent(i: Intent?) {
        if (i == null || !i.getBooleanExtra(X.OPEN, false)) return
        val id = i.getLongExtra(X.MED, 0)
        if (id > 0) {
            vm.openDose = DoseRef(id, i.getLongExtra(X.DAY, 0), i.getIntExtra(X.MIN, 0))
            stopService(Intent(this, AlarmService::class.java))
        }
        i.removeExtra(X.OPEN)
    }

    override fun onResume() {
        super.onResume()
        vm.refresh()
    }
}
